//! Minimal Standard MIDI File (SMF) reader / writer for single patterns.
//!
//! Reading merges every track and channel into one list of notes (tempo / program / controller events
//! are ignored); writing produces a format-0 file with one track and a tempo event.
//! Ticks are converted between the file's resolution and the caller's `ppq`.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MidiNote {
    pub key: u8,
    pub velocity: u8,
    /// Start in ticks (caller's resolution).
    pub start: u32,
    pub len: u32,
}

struct Reader<'a> {
    b: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    fn u8(&mut self) -> Result<u8, String> {
        let v = *self.b.get(self.pos).ok_or("unexpected end of file")?;
        self.pos += 1;
        Ok(v)
    }
    fn u16(&mut self) -> Result<u16, String> {
        Ok(((self.u8()? as u16) << 8) | self.u8()? as u16)
    }
    fn u32(&mut self) -> Result<u32, String> {
        Ok(((self.u16()? as u32) << 16) | self.u16()? as u32)
    }
    fn vlq(&mut self) -> Result<u32, String> {
        let mut v: u32 = 0;
        for _ in 0..4 {
            let b = self.u8()?;
            v = (v << 7) | (b & 0x7f) as u32;
            if b & 0x80 == 0 {
                return Ok(v);
            }
        }
        Err("bad variable-length number".into())
    }
    fn skip(&mut self, n: usize) -> Result<(), String> {
        if self.pos + n > self.b.len() {
            return Err("unexpected end of file".into());
        }
        self.pos += n;
        Ok(())
    }
}

/// Parse a .mid file into notes, scaled to `ppq` ticks per quarter note.
pub fn read(bytes: &[u8], ppq: u32) -> Result<Vec<MidiNote>, String> {
    let mut r = Reader { b: bytes, pos: 0 };
    if bytes.len() < 14 || &bytes[0..4] != b"MThd" {
        return Err("not a MIDI file".into());
    }
    r.pos = 4;
    let hlen = r.u32()? as usize;
    let _format = r.u16()?;
    let ntrks = r.u16()?;
    let division = r.u16()?;
    if division & 0x8000 != 0 {
        return Err("SMPTE time division is not supported".into());
    }
    if division == 0 {
        return Err("bad time division".into());
    }
    r.pos = 8 + hlen.max(6);
    let scale = |t: u64| -> u32 { ((t * ppq as u64 + division as u64 / 2) / division as u64).min(u32::MAX as u64) as u32 };
    let mut out: Vec<MidiNote> = Vec::new();

    for _ in 0..ntrks {
        // find the next track chunk (skip unknown chunks)
        loop {
            if r.pos + 8 > bytes.len() {
                return finish(out);
            }
            let id = &bytes[r.pos..r.pos + 4];
            r.pos += 4;
            let len = r.u32()? as usize;
            if id == b"MTrk" {
                let end = (r.pos + len).min(bytes.len());
                read_track(&mut r, end, &scale, &mut out)?;
                r.pos = end;
                break;
            }
            r.skip(len.min(bytes.len() - r.pos))?;
        }
    }
    finish(out)
}

fn finish(mut out: Vec<MidiNote>) -> Result<Vec<MidiNote>, String> {
    out.sort_by_key(|n| (n.start, n.key));
    Ok(out)
}

fn read_track(r: &mut Reader, end: usize, scale: &dyn Fn(u64) -> u32, out: &mut Vec<MidiNote>) -> Result<(), String> {
    let mut t: u64 = 0;
    let mut status: u8 = 0;
    // pending note-ons per (channel, key): start tick and velocity (a stack, so overlapping repeats work)
    let mut open: Vec<(u8, u8, u64, u8)> = Vec::new();
    while r.pos < end {
        t += r.vlq()? as u64;
        let mut b = r.u8()?;
        if b < 0x80 {
            // running status: the byte is the first data byte
            if status == 0 {
                return Err("corrupt MIDI data".into());
            }
            r.pos -= 1;
            b = status;
        }
        match b {
            0xff => {
                let kind = r.u8()?;
                let len = r.vlq()? as usize;
                r.skip(len)?;
                if kind == 0x2f {
                    break;
                }
            }
            0xf0 | 0xf7 => {
                let len = r.vlq()? as usize;
                r.skip(len)?;
            }
            _ => {
                status = b;
                let (hi, ch) = (b & 0xf0, b & 0x0f);
                match hi {
                    0x80 | 0x90 => {
                        let key = r.u8()?;
                        let vel = r.u8()?;
                        if hi == 0x90 && vel > 0 {
                            open.push((ch, key, t, vel));
                        } else if let Some(i) = open.iter().position(|o| o.0 == ch && o.1 == key) {
                            let (_, _, st, v) = open.remove(i);
                            push(out, scale, key, v, st, t);
                        }
                    }
                    0xa0 | 0xb0 | 0xe0 => r.skip(2)?,
                    0xc0 | 0xd0 => r.skip(1)?,
                    _ => return Err("corrupt MIDI data".into()),
                }
            }
        }
    }
    // notes that never got a note-off end with the track
    for (_, key, st, v) in open {
        push(out, scale, key, v, st, t);
    }
    Ok(())
}

fn push(out: &mut Vec<MidiNote>, scale: &dyn Fn(u64) -> u32, key: u8, vel: u8, st: u64, en: u64) {
    let start = scale(st);
    let len = scale(en).saturating_sub(start).max(1);
    out.push(MidiNote { key, velocity: vel.clamp(1, 127), start, len });
}

fn put_vlq(out: &mut Vec<u8>, mut v: u32) {
    let mut buf = [0u8; 5];
    let mut n = 0;
    buf[n] = (v & 0x7f) as u8;
    v >>= 7;
    while v > 0 {
        n += 1;
        buf[n] = ((v & 0x7f) as u8) | 0x80;
        v >>= 7;
    }
    for i in (0..=n).rev() {
        out.push(buf[i]);
    }
}

/// A format-0 file with one track: tempo `bpm`, 4/4, the notes on channel 1. `ppq` is written as the resolution.
pub fn write(notes: &[MidiNote], ppq: u32, bpm: f32) -> Vec<u8> {
    let mut events: Vec<(u32, u8, u8, u8)> = Vec::new(); // (tick, order: 0 = off, 1 = on, key, velocity)
    for n in notes {
        events.push((n.start, 1, n.key.min(127), n.velocity.clamp(1, 127)));
        events.push((n.start + n.len.max(1), 0, n.key.min(127), 0));
    }
    // at the same tick, note-offs come first so repeated notes retrigger
    events.sort_by_key(|e| (e.0, e.1));

    let mut trk: Vec<u8> = Vec::new();
    let us_per_q = (60_000_000.0 / bpm.clamp(20.0, 400.0)) as u32;
    trk.extend_from_slice(&[0x00, 0xff, 0x51, 0x03, (us_per_q >> 16) as u8, (us_per_q >> 8) as u8, us_per_q as u8]);
    trk.extend_from_slice(&[0x00, 0xff, 0x58, 0x04, 4, 2, 24, 8]);
    let mut last = 0u32;
    for (tick, on, key, vel) in events {
        put_vlq(&mut trk, tick - last);
        last = tick;
        if on == 1 {
            trk.extend_from_slice(&[0x90, key, vel]);
        } else {
            trk.extend_from_slice(&[0x80, key, 0]);
        }
    }
    trk.extend_from_slice(&[0x00, 0xff, 0x2f, 0x00]);

    let mut out: Vec<u8> = Vec::new();
    out.extend_from_slice(b"MThd");
    out.extend_from_slice(&6u32.to_be_bytes());
    out.extend_from_slice(&0u16.to_be_bytes()); // format 0
    out.extend_from_slice(&1u16.to_be_bytes()); // one track
    out.extend_from_slice(&(ppq.min(0x7fff) as u16).to_be_bytes());
    out.extend_from_slice(b"MTrk");
    out.extend_from_slice(&(trk.len() as u32).to_be_bytes());
    out.extend_from_slice(&trk);
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trips_notes() {
        let notes = vec![
            MidiNote { key: 60, velocity: 100, start: 0, len: 480 },
            MidiNote { key: 64, velocity: 70, start: 480, len: 240 },
            MidiNote { key: 60, velocity: 90, start: 480, len: 960 },
            MidiNote { key: 127, velocity: 1, start: 100_000, len: 1 },
        ];
        let bytes = write(&notes, 960, 128.0);
        let mut back = read(&bytes, 960).unwrap();
        let mut want = notes.clone();
        want.sort_by_key(|n| (n.start, n.key));
        back.sort_by_key(|n| (n.start, n.key));
        assert_eq!(back, want);
    }

    #[test]
    fn rescales_to_the_requested_resolution() {
        let notes = vec![MidiNote { key: 62, velocity: 80, start: 480, len: 480 }];
        let bytes = write(&notes, 480, 120.0);
        let back = read(&bytes, 960).unwrap();
        assert_eq!(back, vec![MidiNote { key: 62, velocity: 80, start: 960, len: 960 }]);
    }

    #[test]
    fn reads_running_status_and_note_on_with_zero_velocity() {
        // header: format 0, 1 track, 96 ticks per quarter
        let mut f: Vec<u8> = b"MThd".to_vec();
        f.extend_from_slice(&[0, 0, 0, 6, 0, 0, 0, 1, 0, 96]);
        let trk: Vec<u8> = vec![
            0x00, 0x90, 60, 100, // note on
            0x30, 60, 0, // running status: note on, velocity 0 = off after 48 ticks
            0x00, 62, 90, // running status note on
            0x60, 62, 0, // off
            0x00, 0xff, 0x2f, 0x00,
        ];
        f.extend_from_slice(b"MTrk");
        f.extend_from_slice(&(trk.len() as u32).to_be_bytes());
        f.extend_from_slice(&trk);
        let n = read(&f, 96).unwrap();
        assert_eq!(n, vec![MidiNote { key: 60, velocity: 100, start: 0, len: 48 }, MidiNote { key: 62, velocity: 90, start: 48, len: 96 }]);
    }

    #[test]
    fn rejects_garbage() {
        assert!(read(b"hello world, this is not midi", 960).is_err());
        assert!(read(&[], 960).is_err());
    }
}
