//! Piano roll: the MIDI editor for one pattern.
//!
//! Open a pattern by double-clicking it in the Patterns window or a pattern clip in the playlist.
//! Every playlist clip that uses the pattern follows the edits.
//!
//! Notes
//!   click an empty cell       create a note (then drag it or its edges); Alt = no grid snapping
//!   drag a note               move in time and pitch (the whole selection moves together)
//!   Shift + drag a note       drag a copy of the selected notes (the originals stay)
//!   drag a note's left / right edge   change its start / length
//!   right-click or right-drag erase notes
//!   drag on empty space       rubber-band selection (as in the playlist), Shift / Ctrl adds;  Ctrl + click adds / removes one note
//!   Ctrl+A / Delete           select all / delete (handled in app.rs)
//!   Ctrl+C / X / V / D        copy / cut / paste (at the last clicked position) / duplicate
//!   arrow keys                move the selection: left / right = one grid step, up / down = semitone (Shift = octave)
//! Velocity lane (bottom): drag a stem up / down; drag over empty lane space to "paint" velocities.
//! View: wheel = scroll, horizontal wheel = sideways, Ctrl + wheel = time zoom (around the pointer), Alt + wheel = key height.
//! Until you zoom in, the whole pattern fills the width of the panel; zoomed in, it scrolls sideways (bar + slider).
//! The roll is a dock tab: resize it with the dock separators (the layout is saved). Its layout follows the panel width.
use crate::dialogs;
use crate::state::*;
use crate::theme::*;
use crate::toolbar::{group, seg_button};
use core_engine::{tools, Note, PPQ};
use eframe::egui::{self, pos2, vec2, Align2, Color32, CursorIcon, FontId, Id, PointerButton, Pos2, Rect, RichText, Rounding, Sense, Stroke, Ui, Vec2};
use project_io::midi;
use std::path::{Path, PathBuf};

const KEY_LOW: u8 = 0; // C-1
const KEY_HIGH: u8 = 128; // exclusive: up to G9
const RULER_H: f32 = 24.0;
const HANDLE: f32 = 6.0;
const NOTE_NAMES: [&str; 12] = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
/// Grid resolutions: label and ticks.
const GRIDS: [(&str, u32); 10] = [
    ("1/1", PPQ * 4),
    ("1/2", PPQ * 2),
    ("1/4", PPQ),
    ("1/8", PPQ / 2),
    ("1/16", PPQ / 4),
    ("1/32", PPQ / 8),
    ("1/64", PPQ / 16),
    ("1/4T", PPQ * 2 / 3),
    ("1/8T", PPQ / 3),
    ("1/16T", PPQ / 6),
];
const MAX_BARS: u32 = 256;

#[derive(Clone, Copy, PartialEq)]
enum Zone {
    Left,
    Body,
    Right,
}

#[derive(Clone, Copy, PartialEq)]
enum Region {
    Ruler,
    Keys,
    Grid,
}

#[derive(Clone, Copy)]
enum ImportMode {
    Replace,
    Add,
    NewPattern,
}

enum FileAct {
    Import(ImportMode),
    Export,
}

// ---------------------------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------------------------

/// "C4", "F#2": middle C (key 60) is C4.
fn note_name(key: u8) -> String {
    format!("{}{}", NOTE_NAMES[(key % 12) as usize], key as i32 / 12 - 1)
}

fn is_black(key: u8) -> bool {
    [1, 3, 6, 8, 10].contains(&(key % 12))
}

/// Grid size in ticks (1 = free: grid off or Alt held).
fn eff_snap(s: &State, free: bool) -> u32 {
    if s.roll_snap_on && !free {
        s.snap.max(1)
    } else {
        1
    }
}

fn ceil_bars(t: u32) -> u32 {
    ((t + BAR_TICKS - 1) / BAR_TICKS).max(1) * BAR_TICKS
}

/// Make the pattern long enough to hold something that ends at `end` (whole bars).
fn ensure_len(s: &mut State, end: u32) {
    if end > s.roll_len {
        s.roll_len = ceil_bars(end).min(BAR_TICKS * MAX_BARS);
    }
}

/// `c` with its brightness scaled (alpha stays 255).
fn shade(c: Color32, f: f32) -> Color32 {
    let m = |x: u8| (x as f32 * f).clamp(0.0, 255.0) as u8;
    Color32::from_rgb(m(c.r()), m(c.g()), m(c.b()))
}

/// Topmost note under `p`, and which part of it (left edge, body, right edge).
fn hit_note(notes: &[Note], p: Pos2, left: f32, ppt: f32, top: f32, key_h: f32) -> Option<(usize, Zone)> {
    for (i, n) in notes.iter().enumerate().rev() {
        let y0 = top + (KEY_HIGH - 1 - n.key.min(KEY_HIGH - 1)) as f32 * key_h;
        if p.y < y0 || p.y >= y0 + key_h {
            continue;
        }
        let x0 = left + n.start as f32 * ppt;
        let x1 = (left + (n.start + n.len) as f32 * ppt).max(x0 + 4.0);
        if p.x >= x0 && p.x <= x1 {
            let w = x1 - x0;
            let zone = if w > 14.0 && p.x - x0 < HANDLE {
                Zone::Left
            } else if w > 14.0 && x1 - p.x < HANDLE {
                Zone::Right
            } else {
                Zone::Body
            };
            return Some((i, zone));
        }
    }
    None
}

fn create_note(s: &mut State, tick: u32, key: u8, snap: u32) -> usize {
    let plen = s.roll_len;
    let start = (tick / snap.max(1)) * snap.max(1);
    let len = s.last_len.max(1).min(plen.saturating_sub(start)).max(1);
    s.roll_notes.push(Note { key, velocity: s.last_vel.clamp(1, 127), start, len });
    s.roll_sel = vec![s.roll_notes.len() - 1];
    s.roll_notes.len() - 1
}

// ---- clipboard / duplicate -----------------------------------------------------------------

fn copy_selected(s: &mut State, cut: bool) -> bool {
    let mut v: Vec<Note> = s.roll_sel.iter().filter_map(|&i| s.roll_notes.get(i).copied()).collect();
    if v.is_empty() {
        return false;
    }
    let base = v.iter().map(|n| n.start).min().unwrap_or(0);
    for n in &mut v {
        n.start -= base;
    }
    let count = v.len();
    s.roll_clip = v;
    if cut {
        s.delete_selected_notes(); // also writes the pattern back
        s.toast(format!("Cut {count} note(s)"), false);
    } else {
        s.toast(format!("Copied {count} note(s)"), false);
    }
    true
}

/// Paste at the roll cursor; the pattern grows when the notes stick out. Returns true when something changed.
fn paste_notes(s: &mut State) -> bool {
    if s.roll_clip.is_empty() {
        return false;
    }
    let at = s.roll_cursor.min(BAR_TICKS * MAX_BARS - 1);
    let clip = s.roll_clip.clone();
    let span = clip.iter().map(|n| n.start + n.len).max().unwrap_or(0);
    ensure_len(s, at + span);
    let plen = s.roll_len;
    let first = s.roll_notes.len();
    for n in clip {
        let st = at + n.start;
        if st >= plen {
            continue;
        }
        s.roll_notes.push(Note { start: st, len: n.len.min(plen - st).max(1), ..n });
    }
    s.roll_sel = (first..s.roll_notes.len()).collect();
    // the next paste continues behind this one
    s.roll_cursor = at + span;
    true
}

/// Copies of the selected notes placed right behind the selection (shifted by its length, rounded to the grid).
fn duplicate_selected(s: &mut State) -> bool {
    let src: Vec<Note> = s.roll_sel.iter().filter_map(|&i| s.roll_notes.get(i).copied()).collect();
    if src.is_empty() {
        return false;
    }
    let lo = src.iter().map(|n| n.start).min().unwrap_or(0);
    let hi = src.iter().map(|n| n.start + n.len).max().unwrap_or(0);
    let grid = s.snap.max(1);
    let shift = ((hi - lo + grid - 1) / grid).max(1) * grid;
    ensure_len(s, hi + shift);
    let plen = s.roll_len;
    let first = s.roll_notes.len();
    for n in src {
        let st = n.start + shift;
        if st >= plen {
            continue;
        }
        s.roll_notes.push(Note { start: st, len: n.len.min(plen - st).max(1), ..n });
    }
    s.roll_sel = (first..s.roll_notes.len()).collect();
    true
}

// ---- MIDI files ------------------------------------------------------------------------------

fn import_midi(s: &mut State, path: &Path, mode: ImportMode) {
    let bytes = match std::fs::read(path) {
        Ok(b) => b,
        Err(e) => {
            s.toast(format!("Can't read {}: {e}", path.display()), true);
            return;
        }
    };
    let notes = match midi::read(&bytes, PPQ) {
        Ok(n) => n,
        Err(e) => {
            s.toast(format!("MIDI import failed: {e}"), true);
            return;
        }
    };
    let max_len = BAR_TICKS * MAX_BARS;
    let notes: Vec<Note> = notes.into_iter().filter(|n| n.start < max_len).map(|n| Note { key: n.key, velocity: n.velocity, start: n.start, len: n.len.min(max_len - n.start).max(1) }).collect();
    if notes.is_empty() {
        s.toast("The MIDI file has no notes", true);
        return;
    }
    if let Some(dir) = path.parent() {
        s.cfg.midi_dir = Some(dir.to_path_buf());
    }
    let end = notes.iter().map(|n| n.start + n.len).max().unwrap_or(0);
    let count = notes.len();
    let first = match mode {
        ImportMode::NewPattern => {
            let p = s.add_pattern();
            s.open_pattern(p, None);
            if let (Some(pi), Some(stem)) = (s.pat_index(p), path.file_stem().and_then(|x| x.to_str())) {
                s.patterns[pi].name = stem.to_string();
            }
            s.roll_notes = notes;
            s.roll_len = ceil_bars(end);
            0
        }
        ImportMode::Replace => {
            s.roll_notes = notes;
            s.roll_len = ceil_bars(end);
            0
        }
        ImportMode::Add => {
            let first = s.roll_notes.len();
            s.roll_notes.extend(notes);
            s.roll_len = s.roll_len.max(ceil_bars(end));
            first
        }
    };
    s.roll_sel = (first..s.roll_notes.len()).collect();
    s.sync_roll();
    s.toast(format!("Imported {count} note(s) from {}", path.file_name().and_then(|n| n.to_str()).unwrap_or("MIDI file")), false);
}

fn export_midi(s: &mut State, mut path: PathBuf) {
    let notes: Vec<midi::MidiNote> = s.roll_notes.iter().map(|n| midi::MidiNote { key: n.key, velocity: n.velocity, start: n.start, len: n.len }).collect();
    if notes.is_empty() {
        s.toast("Nothing to export: the pattern has no notes", true);
        return;
    }
    if path.extension().is_none() {
        path.set_extension("mid");
    }
    let bytes = midi::write(&notes, PPQ, s.bpm);
    match std::fs::write(&path, bytes) {
        Ok(()) => {
            if let Some(dir) = path.parent() {
                s.cfg.midi_dir = Some(dir.to_path_buf());
            }
            s.toast(format!("Exported {} note(s) to {}", notes.len(), path.display()), false);
        }
        Err(e) => s.toast(format!("Export failed: {e}"), true),
    }
}

fn run_file_action(s: &mut State, act: FileAct, pattern_name: &str) {
    let typed = s.midi_path_input.trim().trim_matches('"').to_string();
    let native = dialogs::has_native_dialogs();
    match act {
        FileAct::Import(mode) => {
            let path = if native { dialogs::pick_open("mid") } else if typed.is_empty() { None } else { Some(PathBuf::from(typed)) };
            match path {
                Some(p) => import_midi(s, &p, mode),
                None if !native => s.toast("Type the path of a .mid file first", true),
                None => {}
            }
        }
        FileAct::Export => {
            let safe: String = pattern_name.chars().map(|c| if c.is_alphanumeric() || c == ' ' || c == '-' || c == '_' { c } else { '_' }).collect();
            let name = format!("{}.mid", safe.trim());
            let path = if native {
                dialogs::pick_save(&name, "mid", s.cfg.midi_dir.clone())
            } else if typed.is_empty() {
                s.cfg.midi_dir.clone().map(|d| d.join(&name))
            } else {
                Some(PathBuf::from(typed))
            };
            match path {
                Some(p) => export_midi(s, p),
                None if !native => s.toast("Type a path (or set a folder by importing once)", true),
                None => {}
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// the editor
// ---------------------------------------------------------------------------------------------

pub(crate) fn piano_roll(s: &mut State, ui: &mut Ui) {
    let Some(pid) = s.editing_pattern.filter(|&p| s.pat_index(p).is_some()) else {
        ui.add_space(30.0);
        ui.vertical_centered(|ui| {
            ui.label(RichText::new("No pattern open").size(18.0).strong().color(MUTED));
            ui.label(RichText::new("Double-click a pattern in the Patterns window or a pattern clip in the Playlist.").color(MUTED));
            ui.add_space(10.0);
            let b = egui::Button::new(RichText::new("+ New pattern").color(Color32::WHITE)).fill(ACCENT).rounding(Rounding::same(8.0)).min_size(vec2(130.0, 28.0));
            if ui.add(b).clicked() {
                let p = s.add_pattern();
                s.open_pattern(p, None);
            }
        });
        return;
    };
    let pname: String = s.pat_index(pid).map(|i| s.patterns[i].name.clone()).unwrap_or_default();
    // The clip the pattern was opened from decides the track that plays the notes.
    let clip_ctx = s.editing_clip.and_then(|id| s.clip_index(id));
    let track: usize = clip_ctx.map(|ci| s.clips[ci].track).unwrap_or(s.selected_track);
    let clip_start: Option<u32> = clip_ctx.map(|ci| s.clips[ci].start);
    let clip_len: Option<u32> = clip_ctx.map(|ci| s.clips[ci].len_ticks(s.bpm, s.sample_rate));
    let clip_off: u32 = clip_ctx
        .and_then(|ci| match &s.clips[ci].body {
            ClipBody::Pattern { offset, .. } => Some(*offset),
            _ => None,
        })
        .unwrap_or(0);
    let mut changed = false;
    let mut switch_to: Option<u64> = None;
    let mut file_act: Option<FileAct> = None;
    let panel = ui.available_rect_before_wrap();
    let panel_hover = ui.rect_contains_pointer(panel);
    let panel_w = ui.available_width();
    // the layout follows the width of the panel: narrower keyboard, fewer labels, lower velocity lane
    let compact = panel_w < 820.0;
    let tiny = panel_w < 560.0;
    let key_w: f32 = if tiny { 46.0 } else if compact { 58.0 } else { 68.0 };
    let vel_h: f32 = if tiny { 64.0 } else if compact { 80.0 } else { 96.0 };

    // ---- toolbar (wraps onto more rows when the panel is narrow) ----
    ui.horizontal_wrapped(|ui| {
        ui.spacing_mut().item_spacing = vec2(8.0, 6.0);
        let (dot, _) = ui.allocate_exact_size(vec2(10.0, 10.0), Sense::hover());
        ui.painter().circle_filled(dot.center(), 4.5, track_color(track));
        ui.label(RichText::new(s.tracks[track].name.clone()).strong().color(track_color(track)));
        egui::ComboBox::from_id_source("roll_pat").width(if compact { 96.0 } else { 130.0 }).selected_text(pname.as_str()).show_ui(ui, |ui| {
            for p in &s.patterns {
                if ui.selectable_label(p.id == pid, p.name.as_str()).clicked() {
                    switch_to = Some(p.id);
                }
            }
        });

        // MIDI import / export
        ui.menu_button("MIDI \u{25be}", |ui| {
            ui.set_min_width(250.0);
            if !dialogs::has_native_dialogs() {
                ui.label(RichText::new("Path of the .mid file").small().color(MUTED));
                ui.add(egui::TextEdit::singleline(&mut s.midi_path_input).hint_text("C:/music/loop.mid").desired_width(f32::INFINITY));
                ui.add_space(4.0);
            }
            ui.label(RichText::new("IMPORT").size(10.5).strong().color(MUTED));
            if ui.button("Replace notes of this pattern\u{2026}").clicked() {
                file_act = Some(FileAct::Import(ImportMode::Replace));
                ui.close_menu();
            }
            if ui.button("Add to this pattern\u{2026}").clicked() {
                file_act = Some(FileAct::Import(ImportMode::Add));
                ui.close_menu();
            }
            if ui.button("As a new pattern\u{2026}").clicked() {
                file_act = Some(FileAct::Import(ImportMode::NewPattern));
                ui.close_menu();
            }
            ui.separator();
            ui.label(RichText::new("EXPORT").size(10.5).strong().color(MUTED));
            if ui.button("This pattern as .mid\u{2026}").clicked() {
                file_act = Some(FileAct::Export);
                ui.close_menu();
            }
        });

        group(ui, |ui| {
            let playing = s.playing;
            if seg_button(ui, if playing { "Stop" } else { "Play" }, playing, GREEN).on_hover_text("Play from the start of this pattern's clip in the playlist (the track's instrument plays the notes)").clicked() {
                if playing {
                    s.stop_all();
                } else if let Some(cs) = clip_start {
                    s.seek(cs);
                    s.toggle_play();
                } else {
                    s.toast("Place this pattern in the playlist to hear it", false);
                }
            }
        });
        group(ui, |ui| {
            if seg_button(ui, "Undo", false, ACCENT).on_hover_text("Ctrl+Z").clicked() {
                s.undo();
            }
            if seg_button(ui, "Redo", false, ACCENT).on_hover_text("Ctrl+Y").clicked() {
                s.redo();
            }
        });

        // grid
        group(ui, |ui| {
            if seg_button(ui, "Snap", s.roll_snap_on, GREEN).on_hover_text("Snap to the grid. Hold Alt while dragging for free movement.").clicked() {
                s.roll_snap_on = !s.roll_snap_on;
            }
        });
        let before = s.snap;
        let cur = GRIDS.iter().find(|g| g.1 == s.snap).map(|g| g.0).unwrap_or("custom");
        egui::ComboBox::from_id_source("roll_grid").width(58.0).selected_text(cur).show_ui(ui, |ui| {
            for (n, v) in GRIDS.iter() {
                ui.selectable_value(&mut s.snap, *v, *n);
            }
        })
        .response
        .on_hover_text("Grid resolution");
        if s.snap != before {
            s.last_len = s.snap; // new notes are one grid step long
        }

        if !compact {
            ui.label(RichText::new("Length").color(MUTED));
        }
        let len_before = s.roll_len;
        let bars = (s.roll_len / BAR_TICKS).max(1);
        egui::ComboBox::from_id_source("roll_bars").width(64.0).selected_text(format!("{bars} bar")).show_ui(ui, |ui| {
            for b in [1u32, 2, 3, 4, 6, 8, 12, 16, 24, 32, 64] {
                if ui.selectable_label(bars == b, format!("{b} bar")).clicked() {
                    s.roll_len = b * BAR_TICKS;
                }
            }
        });
        if s.roll_len != len_before {
            let l = s.roll_len;
            s.roll_notes.retain(|n| n.start < l);
            s.roll_sel.clear();
            changed = true;
        }

        if !compact {
            ui.label(RichText::new("Scale").color(MUTED));
        }
        egui::ComboBox::from_id_source("root").width(48.0).selected_text(NOTE_NAMES[s.root as usize]).show_ui(ui, |ui| {
            for r in 0..12u8 {
                ui.selectable_value(&mut s.root, r, NOTE_NAMES[r as usize]);
            }
        });
        egui::ComboBox::from_id_source("scale").width(92.0).selected_text(match s.scale {
            Scale::Chromatic => "Chromatic",
            Scale::Major => "Major",
            Scale::Minor => "Minor",
        }).show_ui(ui, |ui| {
            ui.selectable_value(&mut s.scale, Scale::Chromatic, "Chromatic");
            ui.selectable_value(&mut s.scale, Scale::Major, "Major");
            ui.selectable_value(&mut s.scale, Scale::Minor, "Minor");
        });

        // editing tools
        group(ui, |ui| {
            if seg_button(ui, "Select all", false, ACCENT).on_hover_text("Ctrl+A").clicked() {
                s.roll_sel = (0..s.roll_notes.len()).collect();
            }
            if seg_button(ui, "Copy", false, ACCENT).on_hover_text("Ctrl+C").clicked() {
                copy_selected(s, false);
            }
            if seg_button(ui, "Paste", false, ACCENT).on_hover_text("Ctrl+V: at the last clicked position").clicked() {
                changed |= paste_notes(s);
            }
            if seg_button(ui, "Duplicate", false, ACCENT).on_hover_text("Ctrl+D: copy the selection right behind itself").clicked() {
                changed |= duplicate_selected(s);
            }
            if seg_button(ui, "Delete", false, RED).on_hover_text("Delete / right-click a note").clicked() {
                s.delete_selected_notes();
            }
        });
        group(ui, |ui| {
            if seg_button(ui, "Quantize", false, ACCENT).on_hover_text("Snap the starts of the selected notes (all notes when none is selected) to the grid").clicked() {
                let snap = s.snap;
                if s.roll_sel.is_empty() {
                    tools::quantize(&mut s.roll_notes, snap);
                } else {
                    for i in s.roll_sel.clone() {
                        if let Some(n) = s.roll_notes.get_mut(i) {
                            tools::quantize(std::slice::from_mut(n), snap);
                        }
                    }
                }
                changed = true;
            }
            if seg_button(ui, "Chop \u{d7}2", false, ACCENT).clicked() {
                tools::chop(&mut s.roll_notes, 2);
                s.roll_sel.clear();
                changed = true;
            }
            if seg_button(ui, "Clear", false, RED).clicked() {
                s.roll_notes.clear();
                s.roll_sel.clear();
                changed = true;
            }
        });

        // velocity of the selection
        if !compact {
            ui.label(RichText::new("Velocity").color(MUTED));
        }
        let mut vel = s.roll_sel.first().and_then(|&i| s.roll_notes.get(i)).map(|n| n.velocity).unwrap_or(s.last_vel);
        if ui.add(egui::DragValue::new(&mut vel).clamp_range(1..=127).speed(0.5)).on_hover_text("Velocity of the selected notes (and of new notes)").changed() {
            s.last_vel = vel;
            for i in s.roll_sel.clone() {
                if let Some(n) = s.roll_notes.get_mut(i) {
                    n.velocity = vel;
                }
            }
            changed |= !s.roll_sel.is_empty();
        }
        if ui.checkbox(&mut s.roll_vel_on, "Velocity lane").changed() {
            s.roll_init = s.roll_init; // layout only
        }

        // view
        // the width of the pattern always follows the panel, so only the key height is adjustable
        if !compact {
            ui.label(RichText::new("Key height").color(MUTED));
        }
        ui.spacing_mut().slider_width = if compact { 60.0 } else { 80.0 };
        ui.add(egui::Slider::new(&mut s.roll_key_h, 10.0..=32.0).show_value(false)).on_hover_text("Key height (Alt + wheel)");
    });
    if let Some(a) = file_act {
        run_file_action(s, a, &pname);
        return;
    }
    if let Some(p) = switch_to {
        if changed {
            s.sync_roll();
        }
        let clip = s.clips.iter().find(|c| matches!(&c.body, ClipBody::Pattern { pat, .. } if *pat == p)).map(|c| c.id);
        s.open_pattern(p, clip);
        return;
    }
    if panel_w >= 900.0 {
        ui.label(RichText::new("Click: add note \u{b7} drag a note: move (Shift: copy) \u{b7} drag an edge: resize \u{b7} right-click: erase \u{b7} drag on empty: select (Shift / Ctrl adds) \u{b7} Ctrl+C / V / D: copy / paste / duplicate \u{b7} Alt: no snap").size(10.5).color(MUTED));
    }
    ui.add_space(2.0);

    // keyboard shortcuts while the pointer is over the roll
    if panel_hover {
        s.focus_playlist = false;
        let (copy, cut, paste, dup) = ui.input(|i| {
            let ctrl = i.modifiers.ctrl || i.modifiers.command;
            (
                i.events.iter().any(|e| matches!(e, egui::Event::Copy)) || (ctrl && i.key_pressed(egui::Key::C)),
                i.events.iter().any(|e| matches!(e, egui::Event::Cut)) || (ctrl && i.key_pressed(egui::Key::X)),
                i.events.iter().any(|e| matches!(e, egui::Event::Paste(_))) || (ctrl && i.key_pressed(egui::Key::V)),
                ctrl && i.key_pressed(egui::Key::D),
            )
        });
        if cut {
            copy_selected(s, true);
        } else if copy {
            copy_selected(s, false);
        }
        if paste {
            changed |= paste_notes(s);
        }
        if dup {
            changed |= duplicate_selected(s);
        }
        // arrow keys move the whole selection: left / right = one grid step, up / down = one semitone (Shift = octave)
        let (dx, dy) = ui.input(|i| {
            let (mut dx, mut dy) = (0i32, 0i32);
            if !(i.modifiers.ctrl || i.modifiers.command || i.modifiers.alt) {
                dx += i.key_pressed(egui::Key::ArrowRight) as i32 - i.key_pressed(egui::Key::ArrowLeft) as i32;
                dy += i.key_pressed(egui::Key::ArrowUp) as i32 - i.key_pressed(egui::Key::ArrowDown) as i32;
                if i.modifiers.shift {
                    dy *= 12;
                }
            }
            (dx, dy)
        });
        if (dx != 0 || dy != 0) && !s.roll_sel.is_empty() {
            let (step, end) = (eff_snap(s, false) as i64, s.roll_len as i64);
            for i in s.roll_sel.clone() {
                if let Some(n) = s.roll_notes.get_mut(i) {
                    n.start = (n.start as i64 + dx as i64 * step).clamp(0, (end - n.len as i64).max(0)) as u32;
                    n.key = (n.key as i32 + dy).clamp(KEY_LOW as i32, KEY_HIGH as i32 - 1) as u8;
                }
            }
            if dy != 0 {
                if let Some(k) = s.roll_sel.first().and_then(|&i| s.roll_notes.get(i)).map(|n| n.key) {
                    s.start_audition(track, k);
                }
            }
            changed = true;
        }
    }

    let ptick = s.roll_len;
    // Until you zoom in, the whole pattern fills the width of the panel (minus the vertical scroll bar).
    // Ctrl + wheel zooms in (then the roll scrolls sideways); zooming out to the panel width is "fit" again.
    let fit = ((panel_w - key_w - 16.0) / ptick.max(1) as f32).clamp(0.01, 1.2);
    if !s.roll_manual_zoom || s.zoom <= fit {
        s.roll_manual_zoom = false;
        s.zoom = fit;
    }
    let ppt = s.zoom;
    let key_h = s.roll_key_h;
    let rows = (KEY_HIGH - KEY_LOW) as f32;
    let ctrl = ui.input(|i| i.modifiers.ctrl || i.modifiers.command);
    let shift = ui.input(|i| i.modifiers.shift);
    let free = ui.input(|i| i.modifiers.alt);
    let snap = eff_snap(s, free);

    // layout: grid area on top, velocity lane below
    let avail = ui.available_size();
    let vel_total = if s.roll_vel_on { vel_h + 8.0 } else { 0.0 };
    let scroll_row = if s.roll_manual_zoom { 26.0 } else { 0.0 }; // slider under the grid while zoomed in
    let main_h = (avail.y - vel_total - scroll_row).max(120.0);
    let area_rect = Rect::from_min_size(ui.cursor().min, vec2(avail.x, main_h));
    if ui.rect_contains_pointer(area_rect) {
        // Alt + wheel = key height, Ctrl + wheel = time zoom (the scroll area must not move meanwhile)
        let (alt, wy, zoom, ptr) = ui.input(|i| (i.modifiers.alt, i.raw_scroll_delta.y, i.zoom_delta(), i.pointer.hover_pos()));
        if alt && wy != 0.0 {
            s.roll_key_h = (s.roll_key_h * (1.0 + wy * 0.002)).clamp(10.0, 32.0);
            ui.input_mut(|i| {
                i.raw_scroll_delta = Vec2::ZERO;
                i.smooth_scroll_delta = Vec2::ZERO;
            });
        } else if (zoom - 1.0).abs() > 0.001 {
            // zoom around the pointer: the tick under it stays where it is
            let old = s.zoom;
            let new = (old * zoom).clamp(fit, 1.2);
            if let Some(p) = ptr {
                let tick = ((p.x - area_rect.left()) + s.roll_scroll_x - key_w) / old.max(1e-6);
                s.roll_scroll_x = (key_w + tick * new - (p.x - area_rect.left())).max(0.0);
            }
            s.zoom = new;
            s.roll_manual_zoom = new > fit + 1e-6;
        }
    }

    // The horizontal mouse wheel (or a trackpad swipe) scrolls the roll sideways wherever the pointer is
    // over it, also over the velocity lane. It is taken here so the scroll area does not apply it twice.
    if s.roll_manual_zoom && panel_hover {
        let dx = ui.input(|i| i.smooth_scroll_delta.x);
        if dx != 0.0 {
            s.roll_scroll_x = (s.roll_scroll_x - dx).max(0.0);
            ui.input_mut(|i| {
                i.smooth_scroll_delta.x = 0.0;
                i.raw_scroll_delta.x = 0.0;
            });
        }
    }

    let mut area = egui::ScrollArea::both().id_source("roll_scroll").auto_shrink([false, false]).max_height(main_h).horizontal_scroll_offset(s.roll_scroll_x);
    if !s.roll_init {
        s.roll_init = true;
        // start around the notes (or middle C)
        let mid = if s.roll_notes.is_empty() { 66 } else { (s.roll_notes.iter().map(|n| n.key as u32).sum::<u32>() / s.roll_notes.len() as u32) as i32 };
        let y = (KEY_HIGH as i32 - 1 - mid) as f32 * key_h + RULER_H - main_h * 0.5;
        area = area.vertical_scroll_offset(y.max(0.0));
    }
    let out = area.show(ui, |ui| {
        let size = vec2(key_w + ptick as f32 * ppt + if s.roll_manual_zoom { 80.0 } else { 0.0 }, RULER_H + rows * key_h);
        let (resp, painter) = ui.allocate_painter(size, Sense::click_and_drag());
        let rect = resp.rect;
        let vis = ui.clip_rect(); // the part of the roll that is on screen
        let left = rect.left() + key_w;
        let top = rect.top() + RULER_H;
        let right = left + ptick as f32 * ppt;
        let x_of = |tick: f32| left + tick * ppt;
        let y_of = |key: u8| top + (KEY_HIGH - 1 - key) as f32 * key_h;
        let tk = |p: Pos2| -> (u32, u8) {
            let tick = ((p.x - left) / ppt).max(0.0) as u32;
            let row = (((p.y - top) / key_h).floor() as i32).clamp(0, rows as i32 - 1);
            (tick, (KEY_HIGH as i32 - 1 - row) as u8)
        };
        let kb_right = vis.left() + key_w;
        let ruler_bottom = vis.top() + RULER_H;
        let region = |p: Pos2| if p.y < ruler_bottom { Region::Ruler } else if p.x < kb_right { Region::Keys } else { Region::Grid };

        // --- rows ---
        let accent_row = ACCENT.gamma_multiply(0.07);
        for key in KEY_LOW..KEY_HIGH {
            let y = y_of(key);
            if y + key_h < vis.top() || y > vis.bottom() {
                continue;
            }
            let black = is_black(key);
            let mut bg = if black { Color32::from_rgb(21, 23, 29) } else { Color32::from_rgb(30, 32, 39) };
            if s.scale != Scale::Chromatic && s.scale.contains(key, s.root) {
                bg = Color32::from_rgb(bg.r() + 8, bg.g() + 13, bg.b() + 24);
            }
            painter.rect_filled(Rect::from_min_max(pos2(left, y), pos2(right, y + key_h)), 0.0, bg);
            if key % 12 == 0 {
                painter.rect_filled(Rect::from_min_max(pos2(left, y), pos2(right, y + key_h)), 0.0, accent_row);
            }
            let line = if key % 12 == 0 { Color32::from_rgb(70, 74, 92) } else { Color32::from_rgb(37, 39, 46) };
            painter.line_segment([pos2(left, y + key_h), pos2(right, y + key_h)], Stroke::new(1.0_f32, line));
        }
        // beyond the end of the pattern
        painter.rect_filled(Rect::from_min_max(pos2(right, top), pos2(rect.right(), rect.bottom())), 0.0, Color32::from_black_alpha(90));

        // --- vertical grid ---
        let first_vis_tick = ((vis.left() - left) / ppt).floor().max(0.0) as u32;
        let last_vis_tick = (((vis.right() - left) / ppt).ceil().max(0.0) as u32).min(ptick);
        let step = if ppt * (PPQ / 4) as f32 >= 9.0 { PPQ / 4 } else if ppt * PPQ as f32 >= 9.0 { PPQ } else { BAR_TICKS };
        let mut t = (first_vis_tick / step) * step;
        while t <= last_vis_tick {
            let col = if t % BAR_TICKS == 0 {
                Color32::from_rgb(112, 114, 130)
            } else if t % PPQ == 0 {
                Color32::from_rgb(66, 69, 82)
            } else {
                Color32::from_rgb(41, 43, 51)
            };
            painter.line_segment([pos2(x_of(t as f32), top), pos2(x_of(t as f32), rect.bottom())], Stroke::new(1.0_f32, col));
            t += step;
        }
        // the end of the pattern
        painter.line_segment([pos2(right, top), pos2(right, rect.bottom())], Stroke::new(2.0_f32, ACCENT.gamma_multiply(0.7)));

        // --- notes ---
        let tcol = track_color(track);
        for (i, n) in s.roll_notes.iter().enumerate() {
            let r = Rect::from_min_size(pos2(x_of(n.start as f32), y_of(n.key.min(KEY_HIGH - 1))), vec2((n.len as f32 * ppt).max(4.0), key_h)).shrink2(vec2(0.0, 1.0));
            if r.right() < vis.left() || r.left() > vis.right() || r.bottom() < vis.top() || r.top() > vis.bottom() {
                continue;
            }
            let sel = s.roll_sel.contains(&i);
            let f = 0.55 + 0.45 * n.velocity as f32 / 127.0;
            let col = if sel { shade(tcol, f * 1.2) } else { shade(tcol, f) };
            painter.rect_filled(r, 3.0, col);
            painter.rect_filled(Rect::from_min_size(r.min, vec2(r.width(), 3.0)), 3.0, Color32::from_white_alpha(70));
            if r.width() > 14.0 {
                // grips at both ends show that the edges can be dragged
                painter.rect_filled(Rect::from_min_size(r.min, vec2(2.5, r.height())), 1.0, Color32::from_black_alpha(60));
                painter.rect_filled(Rect::from_min_max(pos2(r.right() - 2.5, r.top()), r.max), 1.0, Color32::from_black_alpha(60));
            }
            if r.width() > 30.0 && key_h >= 12.0 {
                painter.text(r.left_center() + vec2(5.0, 0.0), Align2::LEFT_CENTER, note_name(n.key), FontId::proportional((key_h * 0.6).min(11.0)), Color32::from_black_alpha(190));
            }
            if sel {
                painter.rect_stroke(r, 3.0, Stroke::new(1.5_f32, Color32::WHITE));
            }
        }

        // --- hover affordances + cursor ---
        let hover = resp.hover_pos();
        if s.roll_drag.is_none() {
            if let Some(p) = hover {
                match region(p) {
                    Region::Keys | Region::Ruler => ui.ctx().set_cursor_icon(CursorIcon::PointingHand),
                    Region::Grid if p.x <= right => {
                        let (tick, key) = tk(p);
                        match hit_note(&s.roll_notes, p, left, ppt, top, key_h) {
                            Some((_, Zone::Left)) | Some((_, Zone::Right)) => ui.ctx().set_cursor_icon(CursorIcon::ResizeHorizontal),
                            Some((_, Zone::Body)) => ui.ctx().set_cursor_icon(if shift { CursorIcon::Copy } else { CursorIcon::Grab }),
                            None => {
                                ui.ctx().set_cursor_icon(CursorIcon::Crosshair);
                                let start = (tick / snap) * snap;
                                let g = Rect::from_min_size(pos2(x_of(start as f32), y_of(key)), vec2((s.last_len as f32 * ppt).max(4.0), key_h)).shrink2(vec2(0.0, 1.0));
                                painter.rect_filled(g, 3.0, tcol.gamma_multiply(0.3));
                            }
                        }
                    }
                    _ => {}
                }
            }
        }

        // --- right button: erase notes under the pointer (click or drag) ---
        if (resp.is_pointer_button_down_on() && ui.input(|i| i.pointer.secondary_down())) || resp.secondary_clicked() {
            if let Some(p) = resp.interact_pointer_pos() {
                if region(p) == Region::Grid {
                    if let Some((i, _)) = hit_note(&s.roll_notes, p, left, ppt, top, key_h) {
                        s.remove_note(i);
                        changed = true;
                    }
                }
            }
        }

        // --- primary drag start ---
        if resp.drag_started_by(PointerButton::Primary) {
            if let Some(o) = ui.input(|i| i.pointer.press_origin()) {
                match region(o) {
                    Region::Grid if o.x <= right => {
                        let (tick, key) = tk(o);
                        match hit_note(&s.roll_notes, o, left, ppt, top, key_h) {
                            Some((i, zone)) => {
                                if shift && zone == Zone::Body {
                                    // Shift + drag: the selected notes (or the grabbed one) stay, copies are dragged
                                    let src: Vec<usize> = if s.roll_sel.contains(&i) { s.roll_sel.clone() } else { vec![i] };
                                    let mut fresh: Vec<usize> = Vec::new();
                                    for j in src {
                                        if let Some(n) = s.roll_notes.get(j).copied() {
                                            s.roll_notes.push(n);
                                            fresh.push(s.roll_notes.len() - 1);
                                        }
                                    }
                                    s.roll_sel = fresh;
                                } else if !s.roll_sel.contains(&i) {
                                    if ctrl {
                                        s.roll_sel.push(i);
                                    } else {
                                        s.roll_sel = vec![i];
                                    }
                                }
                                let orig: Vec<_> = s.roll_sel.iter().filter_map(|&j| s.roll_notes.get(j).map(|n| (j, n.start, n.key, n.len))).collect();
                                s.roll_drag = Some(match zone {
                                    Zone::Right => RollDrag::Resize { anchor_tick: tick, orig },
                                    Zone::Left => RollDrag::ResizeStart { anchor_tick: tick, orig },
                                    Zone::Body => RollDrag::Move { anchor_tick: tick, anchor_key: key as i32, orig },
                                });
                                if zone == Zone::Body {
                                    let k = s.roll_notes[i].key;
                                    s.start_audition(track, k);
                                }
                            }
                            None => {
                                // dragging over empty space selects, like in the playlist (Shift / Ctrl adds);
                                // a plain click on empty space creates a note (handled below)
                                let additive = shift || ctrl;
                                let base = if additive { s.roll_sel.clone() } else { Vec::new() };
                                if !additive {
                                    s.roll_sel.clear();
                                }
                                s.roll_drag = Some(RollDrag::Marquee { from: o, to: o, base });
                            }
                        }
                    }
                    Region::Keys => {
                        let (_, key) = tk(o);
                        s.start_audition(track, key);
                    }
                    _ => {}
                }
            }
        } else if resp.dragged_by(PointerButton::Primary) {
            if let (Some(p), Some(drag)) = (resp.interact_pointer_pos(), s.roll_drag.take()) {
                let (tick, key) = tk(p);
                let sign = |a: u32, b: u32| if a >= b { 1i64 } else { -1 };
                let drag = match drag {
                    RollDrag::Move { anchor_tick, anchor_key, orig } => {
                        let dt = s.snap_round((tick as f32 - anchor_tick as f32).abs(), snap) as i64 * sign(tick, anchor_tick);
                        let dk = key as i32 - anchor_key;
                        let first_key_before = orig.first().and_then(|o| s.roll_notes.get(o.0)).map(|n| n.key);
                        for &(i, st, k, len) in &orig {
                            if let Some(n) = s.roll_notes.get_mut(i) {
                                n.start = (st as i64 + dt).clamp(0, (ptick as i64 - len as i64).max(0)) as u32;
                                n.key = (k as i32 + dk).clamp(KEY_LOW as i32, KEY_HIGH as i32 - 1) as u8;
                            }
                        }
                        if let (Some(before), Some(o)) = (first_key_before, orig.first()) {
                            if let Some(now) = s.roll_notes.get(o.0).map(|n| n.key) {
                                if now != before {
                                    s.start_audition(track, now);
                                }
                            }
                        }
                        RollDrag::Move { anchor_tick, anchor_key, orig }
                    }
                    RollDrag::Resize { anchor_tick, orig } => {
                        let dt = s.snap_round((tick as f32 - anchor_tick as f32).abs(), snap) as i64 * sign(tick, anchor_tick);
                        for &(i, st, _, len) in &orig {
                            if let Some(n) = s.roll_notes.get_mut(i) {
                                let max_len = (ptick as i64 - st as i64).max(1);
                                n.len = (len as i64 + dt).clamp((snap as i64).min(max_len), max_len) as u32;
                            }
                        }
                        if let Some(n) = orig.first().and_then(|o| s.roll_notes.get(o.0)) {
                            s.last_len = n.len;
                        }
                        RollDrag::Resize { anchor_tick, orig }
                    }
                    RollDrag::ResizeStart { anchor_tick, orig } => {
                        let dt = s.snap_round((tick as f32 - anchor_tick as f32).abs(), snap) as i64 * sign(tick, anchor_tick);
                        for &(i, st, _, len) in &orig {
                            if let Some(n) = s.roll_notes.get_mut(i) {
                                let end = st as i64 + len as i64;
                                let min_len = (snap as i64).min(len as i64).max(1);
                                let new_start = (st as i64 + dt).clamp(0, end - min_len);
                                n.start = new_start as u32;
                                n.len = (end - new_start) as u32;
                            }
                        }
                        if let Some(n) = orig.first().and_then(|o| s.roll_notes.get(o.0)) {
                            s.last_len = n.len;
                        }
                        RollDrag::ResizeStart { anchor_tick, orig }
                    }
                    RollDrag::Marquee { from, base, .. } => {
                        // the selection follows the rectangle while it is dragged
                        let selr = Rect::from_two_pos(from, p);
                        let mut sel = base.clone();
                        for (i, n) in s.roll_notes.iter().enumerate() {
                            if !sel.contains(&i) && Rect::from_min_size(pos2(x_of(n.start as f32), y_of(n.key)), vec2((n.len as f32 * ppt).max(4.0), key_h)).intersects(selr) {
                                sel.push(i);
                            }
                        }
                        s.roll_sel = sel;
                        RollDrag::Marquee { from, to: p, base }
                    }
                    other => other, // the velocity lane drives its own drag
                };
                s.roll_drag = Some(drag);
            }
        }

        // --- drag end ---
        if resp.drag_stopped() {
            match s.roll_drag.take() {
                Some(RollDrag::Marquee { .. }) => {} // the selection was updated while dragging
                Some(RollDrag::Move { orig, .. }) => {
                    if let Some(n) = orig.first().and_then(|o| s.roll_notes.get(o.0)) {
                        s.last_len = n.len;
                    }
                    changed = true;
                }
                Some(RollDrag::Resize { .. }) | Some(RollDrag::ResizeStart { .. }) => changed = true,
                other => s.roll_drag = other,
            }
            s.stop_audition();
        }
        if let Some(RollDrag::Marquee { from, to, .. }) = &s.roll_drag {
            let r = Rect::from_two_pos(*from, *to);
            painter.rect_filled(r, 2.0, ACCENT.gamma_multiply(0.18));
            painter.rect_stroke(r, 2.0, Stroke::new(1.0_f32, ACCENT));
        }

        // --- plain click ---
        if resp.clicked_by(PointerButton::Primary) {
            if let Some(p) = resp.interact_pointer_pos() {
                let (tick, key) = tk(p);
                match region(p) {
                    Region::Keys => s.start_audition(track, key),
                    Region::Ruler => s.roll_cursor = ((tick / snap.max(1)) * snap.max(1)).min(ptick),
                    Region::Grid if p.x <= right => match hit_note(&s.roll_notes, p, left, ppt, top, key_h) {
                        Some((i, _)) => {
                            if ctrl {
                                if let Some(pos) = s.roll_sel.iter().position(|&j| j == i) {
                                    s.roll_sel.remove(pos);
                                } else {
                                    s.roll_sel.push(i);
                                }
                            } else {
                                s.roll_sel = vec![i];
                            }
                            s.start_audition(track, key);
                        }
                        None => {
                            create_note(s, tick, key, snap);
                            s.roll_cursor = (tick / snap) * snap;
                            s.start_audition(track, key);
                            changed = true;
                        }
                    },
                    _ => {}
                }
            }
        }

        // --- playhead (the pattern repeats inside a longer clip) ---
        if s.playing {
            if let (Some(cs), Some(cl)) = (clip_start, clip_len) {
                let rel = s.playhead as i64 - cs as i64;
                if rel >= 0 && (rel as u32) < cl {
                    let x = x_of(((rel as u32 + clip_off) % ptick.max(1)) as f32);
                    painter.line_segment([pos2(x, top), pos2(x, rect.bottom())], Stroke::new(2.0_f32, Color32::WHITE));
                }
            }
        }

        // --- sticky ruler (stays at the top while scrolling vertically) ---
        let rr = Rect::from_min_size(pos2(vis.left(), vis.top()), vec2(vis.width(), RULER_H));
        painter.rect_filled(rr, 0.0, Color32::from_rgb(34, 36, 45));
        painter.rect_filled(Rect::from_min_max(pos2(x_of(ptick as f32).max(rr.left()), rr.top()), rr.max), 0.0, Color32::from_black_alpha(80));
        let bar_px = BAR_TICKS as f32 * ppt;
        let bar_step = if bar_px >= 34.0 { 1 } else if bar_px >= 17.0 { 2 } else if bar_px >= 8.0 { 4 } else { 8 };
        let first_bar = (first_vis_tick / BAR_TICKS / bar_step) * bar_step;
        let mut bar = first_bar;
        while bar * BAR_TICKS <= last_vis_tick {
            let x = x_of((bar * BAR_TICKS) as f32);
            painter.line_segment([pos2(x, rr.top() + 5.0), pos2(x, rr.bottom())], Stroke::new(1.0_f32, Color32::from_rgb(120, 122, 138)));
            painter.text(pos2(x + 4.0, rr.top() + 4.0), Align2::LEFT_TOP, format!("{}", bar + 1), FontId::proportional(11.0), TEXT);
            if ppt * PPQ as f32 >= 26.0 && bar_step == 1 {
                for b in 1..4u32 {
                    let bx = x + b as f32 * PPQ as f32 * ppt;
                    painter.line_segment([pos2(bx, rr.bottom() - 6.0), pos2(bx, rr.bottom())], Stroke::new(1.0_f32, Color32::from_rgb(84, 86, 100)));
                }
            }
            bar += bar_step;
        }
        painter.line_segment([rr.left_bottom(), rr.right_bottom()], Stroke::new(1.0_f32, Color32::from_rgb(12, 13, 17)));
        // paste position
        let cx = x_of(s.roll_cursor as f32);
        if cx >= rr.left() && cx <= rr.right() {
            painter.add(egui::Shape::convex_polygon(vec![pos2(cx - 5.0, rr.bottom() - 9.0), pos2(cx + 5.0, rr.bottom() - 9.0), pos2(cx, rr.bottom() - 1.0)], ACCENT, Stroke::NONE));
            painter.line_segment([pos2(cx, rr.bottom()), pos2(cx, rect.bottom())], Stroke::new(1.0_f32, ACCENT.gamma_multiply(0.45)));
        }

        // --- sticky keyboard with note names and octaves ---
        let hover_key = hover.filter(|&p| region(p) != Region::Ruler && p.x < kb_right).map(|p| tk(p).1);
        let audition_key = s.audition.map(|a| a.1);
        let sel_keys: Vec<u8> = s.roll_sel.iter().filter_map(|&i| s.roll_notes.get(i).map(|n| n.key)).collect();
        painter.rect_filled(Rect::from_min_max(pos2(vis.left(), ruler_bottom), pos2(kb_right, vis.bottom())), 0.0, Color32::from_rgb(222, 224, 231));
        for key in KEY_LOW..KEY_HIGH {
            let y = y_of(key);
            if y + key_h < ruler_bottom || y > vis.bottom() {
                continue;
            }
            let black = is_black(key);
            let lit = audition_key == Some(key) || hover_key == Some(key);
            let in_sel = sel_keys.contains(&key);
            let kr = Rect::from_min_size(pos2(vis.left(), y), vec2(key_w, key_h));
            if black {
                // a black key is shorter than the white ones
                let bk = Rect::from_min_size(kr.min, vec2(key_w * 0.66, key_h));
                painter.rect_filled(bk, Rounding { nw: 0.0, ne: 3.0, sw: 0.0, se: 3.0 }, if lit { ACCENT } else if in_sel { shade(tcol, 0.8) } else { Color32::from_rgb(24, 26, 33) });
                if key_h >= 12.0 {
                    painter.text(bk.right_center() - vec2(5.0, 0.0), Align2::RIGHT_CENTER, note_name(key), FontId::proportional(8.5), Color32::from_white_alpha(190));
                }
            } else {
                if lit {
                    painter.rect_filled(kr, 0.0, ACCENT.gamma_multiply(0.85));
                } else if in_sel {
                    painter.rect_filled(kr, 0.0, shade(tcol, 1.0).gamma_multiply(0.75));
                }
                // white keys always carry their name; every C also shows its octave in bold
                let c = key % 12 == 0;
                if c || key_h >= 12.0 {
                    painter.text(kr.right_center() - vec2(6.0, 0.0), Align2::RIGHT_CENTER, note_name(key), FontId::proportional(if c { 11.0 } else { 9.5 }), if lit { Color32::WHITE } else if c { Color32::from_rgb(20, 22, 30) } else { Color32::from_rgb(90, 94, 108) });
                }
            }
            let sep = if key % 12 == 0 { Color32::from_rgb(40, 42, 52) } else { Color32::from_rgb(160, 162, 172) };
            painter.line_segment([pos2(kr.left(), kr.bottom()), pos2(kr.right(), kr.bottom())], Stroke::new(1.0_f32, sep));
        }
        painter.line_segment([pos2(kb_right, ruler_bottom), pos2(kb_right, vis.bottom())], Stroke::new(1.0_f32, Color32::from_rgb(12, 13, 17)));
        // corner above the keyboard
        painter.rect_filled(Rect::from_min_size(vis.min, vec2(key_w, RULER_H)), 0.0, Color32::from_rgb(28, 30, 38));
        painter.text(pos2(vis.left() + 8.0, vis.top() + RULER_H * 0.5), Align2::LEFT_CENTER, format!("{} bars", ptick / BAR_TICKS), FontId::proportional(10.0), MUTED);
    });

    // sideways scrolling: the bar of the scroll area plus a slider under the grid while zoomed in
    s.roll_scroll_x = out.state.offset.x;
    if s.roll_manual_zoom {
        let max_x = (out.content_size.x - out.inner_rect.width()).max(0.0);
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 8.0;
            ui.label(RichText::new("Scroll").size(11.0).color(MUTED));
            ui.spacing_mut().slider_width = (ui.available_width() - 16.0).max(60.0);
            let mut x = s.roll_scroll_x.min(max_x);
            if ui.add(egui::Slider::new(&mut x, 0.0..=max_x.max(1.0)).show_value(false)).changed() {
                s.roll_scroll_x = x;
            }
        });
    }

    // ---- velocity lane (shares the horizontal scroll of the grid) ----
    if s.roll_vel_on {
        ui.add_space(4.0);
        let (lane, lresp) = ui.allocate_exact_size(vec2(ui.available_width(), vel_h), Sense::click_and_drag());
        let off_x = out.state.offset.x;
        let x0 = lane.left() - off_x + key_w; // tick 0
        let grid_left = lane.left() + key_w;
        let (inner_top, inner_bot) = (lane.top() + 8.0, lane.bottom() - 8.0);
        let span = inner_bot - inner_top;
        let val_at = |y: f32| (((inner_bot - y) / span) * 127.0).round().clamp(1.0, 127.0) as u8;
        let stem_x = |n: &Note| x0 + n.start as f32 * ppt;
        let nearest = |notes: &[Note], px: f32| -> Option<usize> {
            let mut best: Option<(usize, f32)> = None;
            for (i, n) in notes.iter().enumerate() {
                let d = (stem_x(n) - px).abs();
                if d <= 7.0 && best.map_or(true, |b| d < b.1) {
                    best = Some((i, d));
                }
            }
            best.map(|b| b.0)
        };

        // interaction
        if lresp.drag_started_by(PointerButton::Primary) {
            if let Some(o) = ui.input(|i| i.pointer.press_origin()) {
                if o.x >= grid_left {
                    match nearest(&s.roll_notes, o.x) {
                        Some(i) => {
                            if !s.roll_sel.contains(&i) {
                                s.roll_sel = vec![i];
                            }
                            let orig: Vec<(usize, u8)> = s.roll_sel.iter().filter_map(|&j| s.roll_notes.get(j).map(|n| (j, n.velocity))).collect();
                            s.roll_drag = Some(RollDrag::Velocity { orig, anchor_y: o.y });
                        }
                        // an empty orig = "paint": notes under the pointer take the pointer's height
                        None => s.roll_drag = Some(RollDrag::Velocity { orig: Vec::new(), anchor_y: o.y }),
                    }
                }
            }
        }
        if lresp.dragged_by(PointerButton::Primary) {
            if let (Some(p), Some(RollDrag::Velocity { orig, anchor_y })) = (lresp.interact_pointer_pos(), s.roll_drag.take()) {
                let mut hint = None;
                if orig.is_empty() {
                    let v = val_at(p.y);
                    for n in s.roll_notes.iter_mut() {
                        if (x0 + n.start as f32 * ppt - p.x).abs() <= 7.0 {
                            n.velocity = v;
                            hint = Some(v);
                        }
                    }
                } else {
                    let dv = ((anchor_y - p.y) / span * 127.0).round() as i32;
                    for &(i, v) in &orig {
                        if let Some(n) = s.roll_notes.get_mut(i) {
                            n.velocity = (v as i32 + dv).clamp(1, 127) as u8;
                            hint = Some(n.velocity);
                        }
                    }
                }
                if let Some(v) = hint {
                    s.last_vel = v;
                    s.drag_hint = Some((p + vec2(14.0, -26.0), format!("Velocity {v}")));
                }
                s.roll_drag = Some(RollDrag::Velocity { orig, anchor_y });
            }
        }
        if lresp.drag_stopped() {
            if let Some(RollDrag::Velocity { .. }) = s.roll_drag {
                s.roll_drag = None;
                changed = true;
            }
        }
        if lresp.clicked_by(PointerButton::Primary) {
            if let Some(p) = lresp.interact_pointer_pos() {
                if p.x >= grid_left {
                    if let Some(i) = nearest(&s.roll_notes, p.x) {
                        // a click on a stem sets its velocity to the clicked height
                        let v = val_at(p.y);
                        s.roll_notes[i].velocity = v;
                        s.last_vel = v;
                        s.roll_sel = vec![i];
                        changed = true;
                    }
                }
            }
        }

        // painting
        let painter = ui.painter_at(lane);
        painter.rect_filled(lane, 8.0, Color32::from_rgb(20, 22, 29));
        let grid = painter.with_clip_rect(Rect::from_min_max(pos2(grid_left, lane.top()), lane.max));
        for f in [0.0f32, 0.25, 0.5, 0.75, 1.0] {
            let y = inner_bot - f * span;
            grid.line_segment([pos2(grid_left, y), pos2(lane.right(), y)], Stroke::new(1.0_f32, Color32::from_white_alpha(if f == 0.0 || f == 1.0 { 24 } else { 11 })));
        }
        let first_t = (((grid_left - x0) / ppt).floor().max(0.0) as u32 / PPQ) * PPQ;
        let last_t = (((lane.right() - x0) / ppt).ceil().max(0.0) as u32).min(ptick);
        let mut t = first_t;
        while t <= last_t {
            let bar = t % BAR_TICKS == 0;
            if bar || ppt * PPQ as f32 >= 18.0 {
                let x = x0 + t as f32 * ppt;
                grid.line_segment([pos2(x, lane.top()), pos2(x, lane.bottom())], Stroke::new(1.0_f32, Color32::from_white_alpha(if bar { 30 } else { 12 })));
            }
            t += PPQ;
        }
        let end_x = x0 + ptick as f32 * ppt;
        grid.rect_filled(Rect::from_min_max(pos2(end_x, lane.top()), lane.max), 0.0, Color32::from_black_alpha(90));
        let tcol = track_color(track);
        for (i, n) in s.roll_notes.iter().enumerate() {
            let x = stem_x(n);
            if x < grid_left - 4.0 || x > lane.right() + 4.0 {
                continue;
            }
            let h = n.velocity as f32 / 127.0 * span;
            let sel = s.roll_sel.contains(&i);
            let col = if sel { Color32::WHITE } else { tcol };
            grid.line_segment([pos2(x, inner_bot), pos2(x, inner_bot - h)], Stroke::new(if sel { 2.5_f32 } else { 2.0_f32 }, col.gamma_multiply(0.85)));
            grid.circle_filled(pos2(x, inner_bot - h), if sel { 4.2 } else { 3.4 }, col);
        }
        // label column (covers stems that scrolled under it)
        let lab = Rect::from_min_size(lane.min, vec2(key_w, lane.height()));
        painter.rect_filled(lab, Rounding { nw: 8.0, ne: 0.0, sw: 8.0, se: 0.0 }, Color32::from_rgb(28, 30, 38));
        painter.text(pos2(lab.left() + 10.0, lab.top() + 10.0), Align2::LEFT_TOP, "VELOCITY", FontId::proportional(9.5), MUTED);
        for (f, label) in [(1.0f32, "127"), (0.5, "64"), (0.0, "1")] {
            painter.text(pos2(lab.right() - 8.0, inner_bot - f * span), Align2::RIGHT_CENTER, label, FontId::proportional(9.0), MUTED);
        }
        painter.rect_stroke(lane, 8.0, Stroke::new(1.0_f32, STROKE));
        if lresp.hovered() {
            ui.ctx().set_cursor_icon(CursorIcon::ResizeVertical);
        }
    }

    if changed {
        s.sync_roll();
    }
}
