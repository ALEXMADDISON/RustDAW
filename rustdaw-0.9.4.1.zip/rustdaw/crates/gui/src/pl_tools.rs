//! Playlist tools: the palette (icons drawn with the painter, no icon font needed),
//! keyboard shortcuts and the reference shown in Settings.
use crate::theme::*;
use crate::toolbar::group;
use eframe::egui::{self, pos2, vec2, Align2, Color32, FontId, Key, Painter, Pos2, Response, RichText, Sense, Shape, Stroke, Ui, Vec2};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum PlTool {
    /// Place patterns: click = one pattern clip, drag = set its length.
    Draw,
    /// Move clips; dragging empty space scrolls the view.
    Move,
    /// Cut a clip where you click.
    Slice,
    /// Select clips (rubber band, Shift / Ctrl adds). Clips can still be dragged.
    Select,
    /// Click = zoom in, right-click = zoom out, drag a rectangle = zoom to it.
    Zoom,
}

impl PlTool {
    pub const ALL: [PlTool; 5] = [PlTool::Draw, PlTool::Move, PlTool::Slice, PlTool::Select, PlTool::Zoom];

    pub fn name(self) -> &'static str {
        match self {
            PlTool::Draw => "Create pattern",
            PlTool::Move => "Move",
            PlTool::Slice => "Slice",
            PlTool::Select => "Select",
            PlTool::Zoom => "Zoom",
        }
    }

    pub fn key_label(self) -> &'static str {
        match self {
            PlTool::Draw => "P",
            PlTool::Move => "M",
            PlTool::Slice => "C",
            PlTool::Select => "E",
            PlTool::Zoom => "Z",
        }
    }

    pub fn hint(self) -> &'static str {
        match self {
            PlTool::Draw => "Click a track to place the selected pattern; drag sideways to set its length.",
            PlTool::Move => "Drag clips to move them (Shift = drag a copy). Drag empty space to scroll the playlist sideways.",
            PlTool::Slice => "Click a clip to cut it there. Cuts snap to the grid; hold Alt to cut anywhere.",
            PlTool::Select => "Drag a rectangle to select clips; Shift or Ctrl adds to the selection. Clips can still be dragged.",
            PlTool::Zoom => "Click to zoom in, right-click to zoom out, drag a rectangle to zoom to it.",
        }
    }
}

/// Letter and digit shortcuts (no modifier keys held).
const KEYS: [(Key, PlTool); 10] = [
    (Key::P, PlTool::Draw),
    (Key::M, PlTool::Move),
    (Key::C, PlTool::Slice),
    (Key::E, PlTool::Select),
    (Key::Z, PlTool::Zoom),
    (Key::Num1, PlTool::Draw),
    (Key::Num2, PlTool::Move),
    (Key::Num3, PlTool::Slice),
    (Key::Num4, PlTool::Select),
    (Key::Num5, PlTool::Zoom),
];

/// The tool whose shortcut was pressed this frame (only without Ctrl / Alt / Shift).
pub(crate) fn shortcut_pressed(ctx: &egui::Context) -> Option<PlTool> {
    ctx.input(|i| {
        let m = &i.modifiers;
        if m.ctrl || m.alt || m.shift || m.command {
            return None;
        }
        KEYS.iter().find(|(k, _)| i.key_pressed(*k)).map(|(_, t)| *t)
    })
}

impl PlTool {
    /// Neon colour of the tool's icon: every tool has its own.
    pub fn neon(self) -> Color32 {
        match self {
            PlTool::Draw => Color32::from_rgb(57, 255, 136),   // green
            PlTool::Move => Color32::from_rgb(0, 229, 255),    // cyan
            PlTool::Slice => Color32::from_rgb(255, 77, 109),  // pink-red
            PlTool::Select => Color32::from_rgb(255, 214, 10), // yellow
            PlTool::Zoom => Color32::from_rgb(178, 107, 255),  // violet
        }
    }
}

/// `c` mixed towards white by `t` (0..1): the hot core of a neon tube.
fn bright(c: Color32, t: f32) -> Color32 {
    let m = |x: u8| (x as f32 + (255.0 - x as f32) * t) as u8;
    Color32::from_rgb(m(c.r()), m(c.g()), m(c.b()))
}

fn dash(p: &Painter, a: Pos2, b: Pos2, col: Color32, k: f32, grow: f32) {
    p.extend(Shape::dashed_line(&[a, b], Stroke::new(1.3_f32 * k + grow, col), 2.6 * k, 2.2 * k));
}

/// Draws the icon of `tool` centred on `c`. `k` scales it (1.0 = about 22 px). `grow` thickens every
/// stroke and outlines every fill (used for the glow passes); `flat` paints everything in `col` only.
fn draw_icon(p: &Painter, c: Pos2, tool: PlTool, col: Color32, k: f32, grow: f32, flat: bool) {
    let stroke = Stroke::new(1.8_f32 * k + grow, col);
    let thin = |w: f32| Stroke::new(w * k + grow, col);
    let edge = if grow > 0.0 { Stroke::new(grow, col) } else { Stroke::NONE };
    let v = |x: f32, y: f32| vec2(x, y) * k;
    let tone = |m: f32| if flat { col } else { col.gamma_multiply(m) };
    let poly = |pts: Vec<Pos2>, fill: Color32| {
        p.add(Shape::convex_polygon(pts, fill, edge));
    };
    match tool {
        PlTool::Draw => {
            // pencil pointing down-left
            let d: Vec2 = vec2(0.7071, -0.7071);
            let n: Vec2 = vec2(0.7071, 0.7071);
            let hw = 2.8_f32 * k;
            let tip = c - d * (9.0 * k);
            let a = c - d * (4.2 * k);
            let e = c + d * (4.6 * k);
            let cap = c + d * (8.2 * k);
            poly(vec![a + n * hw, a - n * hw, e - n * hw, e + n * hw], col);
            poly(vec![tip, a + n * hw, a - n * hw], tone(0.72));
            if !flat {
                poly(vec![tip, tip + d * (2.6 * k) + n * (0.95 * k), tip + d * (2.6 * k) - n * (0.95 * k)], Color32::from_black_alpha(190));
            }
            poly(vec![e + n * hw, e - n * hw, cap - n * hw, cap + n * hw], tone(0.5));
            if !flat {
                p.line_segment([e + n * hw, e - n * hw], Stroke::new(1.0_f32, Color32::from_black_alpha(120)));
            }
        }
        PlTool::Move => {
            // four-way arrow
            let r = 6.6_f32 * k;
            p.line_segment([c + vec2(-r, 0.0), c + vec2(r, 0.0)], stroke);
            p.line_segment([c + vec2(0.0, -r), c + vec2(0.0, r)], stroke);
            for dir in [vec2(1.0, 0.0), vec2(-1.0, 0.0), vec2(0.0, 1.0), vec2(0.0, -1.0)] {
                let perp = vec2(-dir.y, dir.x);
                let tip = c + dir * (r + 3.6 * k);
                let base = c + dir * (r - 1.2 * k);
                poly(vec![tip, base + perp * (3.4 * k), base - perp * (3.4 * k)], col);
            }
        }
        PlTool::Slice => {
            // scissors: two crossing blades and two finger rings
            p.line_segment([c + v(-5.6, -9.4), c + v(3.6, 5.2)], stroke);
            p.line_segment([c + v(5.6, -9.4), c + v(-3.6, 5.2)], stroke);
            p.circle_stroke(c + v(4.7, 8.0), 2.9 * k, thin(1.6));
            p.circle_stroke(c + v(-4.7, 8.0), 2.9 * k, thin(1.6));
            p.circle_filled(c + v(0.0, -0.9), 1.1 * k + grow * 0.5, col);
        }
        PlTool::Select => {
            // dashed rectangle with a pointer arrow
            let (a, b) = (c + v(-9.5, -9.5), c + v(6.5, 5.5));
            dash(p, a, pos2(b.x, a.y), col, k, grow);
            dash(p, pos2(b.x, a.y), b, col, k, grow);
            dash(p, b, pos2(a.x, b.y), col, k, grow);
            dash(p, pos2(a.x, b.y), a, col, k, grow);
            let t = c + v(-0.5, -2.0);
            poly(vec![t, t + v(0.0, 11.0), t + v(7.8, 8.2)], col);
            p.line_segment([t + v(3.6, 7.6), t + v(8.6, 13.0)], thin(2.2));
        }
        PlTool::Zoom => {
            // magnifying glass with a plus
            let lens = c + v(-2.2, -2.2);
            p.circle_stroke(lens, 6.2 * k, stroke);
            p.line_segment([c + v(2.4, 2.4), c + v(8.8, 8.8)], thin(2.8));
            p.line_segment([lens + v(-2.8, 0.0), lens + v(2.8, 0.0)], thin(1.4));
            p.line_segment([lens + v(0.0, -2.8), lens + v(0.0, 2.8)], thin(1.4));
        }
    }
}

/// Neon icon: a soft halo in the tool's colour (three passes of growing width) and a hot, slightly
/// whitened core on top. `k` = size (1.0 = 22 px), `power` = how strongly it glows (0.5 dim .. 1.2 lit).
pub(crate) fn paint_neon(p: &Painter, c: Pos2, tool: PlTool, k: f32, power: f32) {
    let col = tool.neon();
    for (grow, a) in [(7.0_f32, 0.07_f32), (4.2, 0.15), (2.2, 0.30)] {
        draw_icon(p, c, tool, col.gamma_multiply((a * power).min(1.0)), k, grow, true);
    }
    draw_icon(p, c, tool, bright(col, (0.12 + 0.25 * power).min(0.5)), k, 0.0, false);
}

/// One tool button of the palette: small, dark, with the icon glowing in its own colour.
fn tool_button(ui: &mut Ui, tool: PlTool, active: bool) -> Response {
    let (rect, resp) = ui.allocate_exact_size(vec2(30.0, 26.0), Sense::click());
    let col = tool.neon();
    {
        let p = ui.painter();
        if active {
            p.rect_filled(rect, 8.0, col.gamma_multiply(0.14));
            p.rect_stroke(rect.expand(1.5), 9.0, Stroke::new(3.0_f32, col.gamma_multiply(0.14)));
            p.rect_stroke(rect, 8.0, Stroke::new(1.0_f32, col.gamma_multiply(0.85)));
        } else if resp.is_pointer_button_down_on() {
            p.rect_filled(rect, 8.0, Color32::from_white_alpha(30));
        } else if resp.hovered() {
            p.rect_filled(rect, 8.0, Color32::from_white_alpha(16));
        }
        let power = if active { 1.2 } else if resp.hovered() { 0.95 } else { 0.55 };
        paint_neon(p, rect.center() + vec2(-1.0, -1.0), tool, 0.68, power);
        p.text(rect.right_bottom() - vec2(3.5, 2.0), Align2::RIGHT_BOTTOM, tool.key_label(), FontId::proportional(8.0), if active { col.gamma_multiply(0.9) } else { MUTED });
    }
    resp.on_hover_ui(|ui| {
        ui.label(RichText::new(format!("{}   ({})", tool.name(), tool.key_label())).strong().color(col));
        ui.label(RichText::new(tool.hint()).small().color(MUTED));
    })
}

/// The five tools in a recessed group; clicking one makes it the current tool.
pub(crate) fn tool_palette(ui: &mut Ui, current: &mut PlTool) {
    group(ui, |ui| {
        for t in PlTool::ALL {
            if tool_button(ui, t, *current == t).clicked() {
                *current = t;
            }
        }
    });
}

/// "Playlist tools" card for the Settings window: every tool with its icon, shortcut and what it does.
pub(crate) fn settings_section(ui: &mut Ui) {
    ui.label(RichText::new("Playlist tools").size(20.0).strong());
    ui.label(RichText::new("Pick a tool in the playlist toolbar or press its key while the playlist is under the mouse.").small().color(MUTED));
    ui.add_space(8.0);
    egui::Frame::none().fill(CARD).rounding(egui::Rounding::same(12.0)).inner_margin(egui::Margin::same(12.0)).show(ui, |ui| {
        ui.set_width(ui.available_width());
        for (k, t) in PlTool::ALL.into_iter().enumerate() {
            if k > 0 {
                ui.add_space(6.0);
            }
            ui.horizontal(|ui| {
                let (rect, _) = ui.allocate_exact_size(vec2(34.0, 30.0), Sense::hover());
                ui.painter().rect_filled(rect, 8.0, Color32::from_black_alpha(70));
                paint_neon(ui.painter(), rect.center() + vec2(-1.0, -1.0), t, 0.75, 0.9);
                ui.vertical(|ui| {
                    ui.horizontal(|ui| {
                        ui.label(RichText::new(t.name()).strong().color(t.neon()));
                        ui.label(RichText::new(format!("{}  /  {}", t.key_label(), PlTool::ALL.iter().position(|x| *x == t).map(|i| i + 1).unwrap_or(0))).monospace().small().color(ACCENT));
                    });
                    ui.label(RichText::new(t.hint()).small().color(MUTED));
                });
            });
        }
    });
}
