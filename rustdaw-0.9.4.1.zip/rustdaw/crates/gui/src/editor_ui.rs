//! Visual building blocks for the Sample Editor: a neon waveform view and a small set of minimal,
//! rounded controls (pill buttons, glowing sliders, switches, segmented control).
use crate::theme::*;
use dsp::SampleData;
use eframe::egui::{self, epaint::Mesh, pos2, vec2, Align2, Color32, FontId, Frame, Id, Margin, Painter, Pos2, Rect, Response, RichText, Sense, Shape, Stroke, Ui};
use std::ops::RangeInclusive;
use std::sync::Arc;

pub(crate) const NEON: Color32 = Color32::from_rgb(44, 226, 255);
pub(crate) const AMBER: Color32 = Color32::from_rgb(255, 196, 72);
const WIN_BG: Color32 = Color32::from_rgb(21, 23, 29);
const WAVE_BG: Color32 = Color32::from_rgb(12, 14, 19);
const CTRL_BG: Color32 = Color32::from_rgb(33, 37, 47);
const CTRL_HI: Color32 = Color32::from_rgb(44, 50, 64);
const LINE: Color32 = Color32::from_rgb(52, 58, 74);

fn alpha(c: Color32, a: u8) -> Color32 {
    Color32::from_rgba_unmultiplied(c.r(), c.g(), c.b(), a)
}

fn mix(a: Color32, b: Color32, t: f32) -> Color32 {
    let l = |x: u8, y: u8| (x as f32 + (y as f32 - x as f32) * t).round() as u8;
    Color32::from_rgb(l(a.r(), b.r()), l(a.g(), b.g()), l(a.b(), b.b()))
}

/// Push a colour to full brightness (keeping its hue) so it reads as "neon" on a dark background.
pub(crate) fn neon_of(c: Color32) -> Color32 {
    let m = c.r().max(c.g()).max(c.b()).max(1) as f32;
    let k = 255.0 / m;
    let b = Color32::from_rgb((c.r() as f32 * k).min(255.0) as u8, (c.g() as f32 * k).min(255.0) as u8, (c.b() as f32 * k).min(255.0) as u8);
    b
}

pub(crate) fn window_frame() -> Frame {
    Frame::none()
        .fill(WIN_BG)
        .stroke(Stroke::new(1.0_f32, LINE))
        .rounding(16.0)
        .inner_margin(Margin::same(18.0))
        .shadow(egui::epaint::Shadow { offset: vec2(0.0, 16.0), blur: 44.0, spread: 0.0, color: Color32::from_black_alpha(170) })
}

pub(crate) fn section_label(ui: &mut Ui, text: &str) {
    ui.label(RichText::new(text).size(10.5).color(MUTED).strong());
}

// ------------------------------------------------------------------------------------ buttons

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Btn {
    Primary,
    Secondary,
    Ghost,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Icon {
    Play,
    Stop,
}

/// Rounded pill button. `Primary` glows in the accent colour.
pub(crate) fn pill_button(ui: &mut Ui, text: &str, kind: Btn, icon: Option<Icon>, height: f32) -> Response {
    let font = FontId::proportional(if height < 28.0 { 12.0 } else { 13.0 });
    let galley = ui.fonts(|f| f.layout_no_wrap(text.to_string(), font, Color32::WHITE));
    let icon_w = if icon.is_some() { 20.0 } else { 0.0 };
    let pad = if height < 28.0 { 10.0 } else { 16.0 };
    let (rect, resp) = ui.allocate_exact_size(vec2(galley.size().x + pad * 2.0 + icon_w, height), Sense::click());
    let h = ui.ctx().animate_bool(resp.id, resp.hovered());
    let down = resp.is_pointer_button_down_on();
    let r = height * 0.5;
    let p = ui.painter();
    let (fg, bg) = match kind {
        Btn::Primary => {
            for i in 1..=4 {
                p.rect_filled(rect.expand(i as f32 * 2.4), r + i as f32 * 2.4, alpha(NEON, ((18 - i * 3) as f32 * (0.55 + 0.45 * h)) as u8));
            }
            (Color32::from_rgb(6, 20, 26), mix(NEON, if down { Color32::BLACK } else { Color32::WHITE }, if down { 0.12 } else { 0.16 * h }))
        }
        Btn::Secondary => {
            p.rect_stroke(rect, r, Stroke::new(1.0_f32, mix(LINE, NEON, 0.45 * h)));
            (mix(TEXT, Color32::WHITE, h * 0.5), mix(CTRL_BG, CTRL_HI, h))
        }
        Btn::Ghost => (mix(MUTED, TEXT, h), alpha(Color32::WHITE, (10.0 * h) as u8)),
    };
    let fill_rect = if kind == Btn::Secondary { rect.shrink(1.0) } else { rect };
    p.rect_filled(fill_rect, r, bg);
    let cy = rect.center().y;
    let mut tx = rect.left() + pad;
    if let Some(ic) = icon {
        let c = pos2(tx + 6.0, cy);
        match ic {
            Icon::Play => {
                p.add(Shape::convex_polygon(vec![pos2(c.x - 4.0, c.y - 5.5), pos2(c.x - 4.0, c.y + 5.5), pos2(c.x + 5.5, c.y)], fg, Stroke::NONE));
            }
            Icon::Stop => {
                p.rect_filled(Rect::from_center_size(c, vec2(10.0, 10.0)), 2.0, fg);
            }
        }
        tx += icon_w;
    }
    p.galley(pos2(tx, cy - galley.size().y * 0.5), galley, fg);
    resp
}

/// Round "×" button for the window header.
pub(crate) fn close_button(ui: &mut Ui) -> Response {
    let (rect, resp) = ui.allocate_exact_size(vec2(26.0, 26.0), Sense::click());
    let h = ui.ctx().animate_bool(resp.id, resp.hovered());
    let p = ui.painter();
    p.circle_filled(rect.center(), 13.0, alpha(Color32::WHITE, (8.0 + 22.0 * h) as u8));
    let c = mix(MUTED, TEXT, h);
    let d = 4.5;
    let ctr = rect.center();
    p.line_segment([ctr + vec2(-d, -d), ctr + vec2(d, d)], Stroke::new(1.5_f32, c));
    p.line_segment([ctr + vec2(-d, d), ctr + vec2(d, -d)], Stroke::new(1.5_f32, c));
    resp
}

// ------------------------------------------------------------------------------------ inputs

/// Glowing slider. `bipolar` fills from the centre (pan, pitch). Double-click resets to `default`.
pub(crate) fn neon_slider(ui: &mut Ui, value: &mut f32, range: RangeInclusive<f32>, default: f32, bipolar: bool, color: Color32, width: f32) -> Response {
    let (rect, mut resp) = ui.allocate_exact_size(vec2(width, 24.0), Sense::click_and_drag());
    let (lo, hi) = (*range.start(), *range.end());
    let pad = 9.0;
    let track = Rect::from_min_max(pos2(rect.left() + pad, rect.center().y - 2.5), pos2(rect.right() - pad, rect.center().y + 2.5));
    if resp.dragged() || resp.clicked() {
        if let Some(pt) = resp.interact_pointer_pos() {
            let t = ((pt.x - track.left()) / track.width()).clamp(0.0, 1.0);
            let mut nv = lo + (hi - lo) * t;
            if (nv - default).abs() < (hi - lo) * 0.012 {
                nv = default; // magnetic centre / default
            }
            if (nv - *value).abs() > f32::EPSILON {
                *value = nv;
                resp.mark_changed();
            }
        }
    }
    if resp.double_clicked() {
        *value = default;
        resp.mark_changed();
    }
    let t = ((*value - lo) / (hi - lo)).clamp(0.0, 1.0);
    let x = track.left() + track.width() * t;
    let h = ui.ctx().animate_bool(resp.id, resp.hovered() || resp.dragged());
    let p = ui.painter();
    p.rect_filled(track, 2.5, Color32::from_rgb(38, 43, 55));
    let (a, b) = if bipolar { (track.center().x.min(x), track.center().x.max(x)) } else { (track.left(), x) };
    if b - a > 0.5 {
        let fill = Rect::from_min_max(pos2(a, track.top()), pos2(b, track.bottom()));
        p.rect_filled(fill.expand2(vec2(0.0, 3.0)), 5.0, alpha(color, 26));
        p.rect_filled(fill, 2.5, color);
    }
    if bipolar {
        p.line_segment([pos2(track.center().x, track.top() - 3.0), pos2(track.center().x, track.bottom() + 3.0)], Stroke::new(1.0_f32, alpha(Color32::WHITE, 40)));
    }
    let c = pos2(x, track.center().y);
    for (i, a) in [(14.0, 16u8), (10.5, 34), (8.0, 60)] {
        p.circle_filled(c, i * (0.8 + 0.2 * h), alpha(color, (a as f32 * (0.5 + 0.5 * h)) as u8));
    }
    p.circle_filled(c, 5.5 + 1.0 * h, Color32::from_rgb(235, 250, 255));
    p.circle_stroke(c, 5.5 + 1.0 * h, Stroke::new(1.5_f32, color));
    resp
}

/// Flat numeric field (drag or click to type).
pub(crate) fn value_pill(ui: &mut Ui, value: &mut f32, range: RangeInclusive<f32>, speed: f64, decimals: usize, suffix: &str, width: f32) -> Response {
    ui.scope(|ui| {
        let v = ui.visuals_mut();
        v.override_text_color = Some(mix(NEON, Color32::WHITE, 0.55));
        for w in [&mut v.widgets.inactive, &mut v.widgets.hovered, &mut v.widgets.active, &mut v.widgets.noninteractive] {
            w.bg_fill = CTRL_BG;
            w.weak_bg_fill = CTRL_BG;
            w.bg_stroke = Stroke::NONE;
            w.rounding = 9.0.into();
        }
        v.widgets.hovered.weak_bg_fill = CTRL_HI;
        v.widgets.hovered.bg_fill = CTRL_HI;
        v.widgets.hovered.bg_stroke = Stroke::new(1.0_f32, alpha(NEON, 90));
        ui.add_sized([width, 24.0], egui::DragValue::new(value).clamp_range(range).speed(speed).max_decimals(decimals).min_decimals(decimals).suffix(suffix))
    })
    .inner
}

/// iOS-style switch with a label.
pub(crate) fn toggle_switch(ui: &mut Ui, on: &mut bool, label: &str) -> Response {
    let galley = ui.fonts(|f| f.layout_no_wrap(label.to_string(), FontId::proportional(12.5), Color32::WHITE));
    let (rect, mut resp) = ui.allocate_exact_size(vec2(36.0 + 10.0 + galley.size().x, 22.0), Sense::click());
    if resp.clicked() {
        *on = !*on;
        resp.mark_changed();
    }
    let t = ui.ctx().animate_bool(resp.id, *on);
    let h = ui.ctx().animate_bool(resp.id.with("h"), resp.hovered());
    let track = Rect::from_min_size(pos2(rect.left(), rect.center().y - 9.0), vec2(36.0, 18.0));
    let p = ui.painter();
    if t > 0.01 {
        p.rect_filled(track.expand(3.0), 12.0, alpha(NEON, (30.0 * t) as u8));
    }
    p.rect_filled(track, 9.0, mix(CTRL_BG, alpha_over(NEON, 0.85), t));
    let kx = track.left() + 9.0 + 18.0 * t;
    p.circle_filled(pos2(kx, track.center().y), 6.5, mix(Color32::from_rgb(170, 178, 195), Color32::WHITE, t.max(h * 0.5)));
    p.galley(pos2(rect.left() + 46.0, rect.center().y - galley.size().y * 0.5), galley, mix(MUTED, TEXT, t.max(h)));
    resp
}

fn alpha_over(c: Color32, k: f32) -> Color32 {
    mix(WIN_BG, c, k)
}

/// Segmented control; returns true when the selection changed.
pub(crate) fn segmented(ui: &mut Ui, labels: &[&str], tips: &[&str], sel: &mut usize, width: f32) -> bool {
    let (rect, _) = ui.allocate_exact_size(vec2(width, 28.0), Sense::hover());
    ui.painter().rect_filled(rect, 14.0, Color32::from_rgb(27, 30, 39));
    let n = labels.len().max(1);
    let w = rect.width() / n as f32;
    let mut changed = false;
    for (i, l) in labels.iter().enumerate() {
        let r = Rect::from_min_size(pos2(rect.left() + w * i as f32, rect.top()), vec2(w, rect.height()));
        let resp = ui.interact(r, Id::new(("seg", ui.id(), i)), Sense::click());
        let on = *sel == i;
        let h = ui.ctx().animate_bool(resp.id, on);
        let hv = ui.ctx().animate_bool(resp.id.with("h"), resp.hovered());
        let p = ui.painter();
        if h > 0.01 {
            let inner = r.shrink(3.0);
            p.rect_filled(inner.expand(2.0), 13.0, alpha(NEON, (22.0 * h) as u8));
            p.rect_filled(inner, 11.0, alpha(NEON, (46.0 * h) as u8));
            p.rect_stroke(inner, 11.0, Stroke::new(1.0_f32, alpha(NEON, (150.0 * h) as u8)));
        }
        p.text(r.center(), Align2::CENTER_CENTER, l, FontId::proportional(12.0), mix(mix(MUTED, TEXT, hv), Color32::from_rgb(214, 250, 255), h));
        if let Some(t) = tips.get(i) {
            resp.clone().on_hover_text(*t);
        }
        if resp.clicked() && !on {
            *sel = i;
            changed = true;
        }
    }
    changed
}

pub(crate) fn stat(ui: &mut Ui, label: &str, value: String) {
    ui.vertical(|ui| {
        ui.spacing_mut().item_spacing.y = 1.0;
        ui.label(RichText::new(label).size(10.0).color(MUTED).strong());
        ui.label(RichText::new(value).monospace().size(15.0).color(TEXT));
    });
}

/// Pulsing "rendering" badge.
pub(crate) fn busy_chip(ui: &mut Ui) {
    let t = (ui.input(|i| i.time) * 4.0).sin() as f32 * 0.5 + 0.5;
    let (rect, _) = ui.allocate_exact_size(vec2(96.0, 22.0), Sense::hover());
    let p = ui.painter();
    p.rect_filled(rect, 11.0, alpha(NEON, 24));
    p.circle_filled(pos2(rect.left() + 12.0, rect.center().y), 3.5, alpha(NEON, (110.0 + 145.0 * t) as u8));
    p.text(pos2(rect.left() + 22.0, rect.center().y), Align2::LEFT_CENTER, "RENDERING", FontId::proportional(10.0), NEON);
    ui.ctx().request_repaint();
}

// ------------------------------------------------------------------------------------ waveform

type ColKey = (usize, usize, usize);

/// min/max envelope of both channels, one entry per physical pixel column (cached between frames).
fn wave_columns(ctx: &egui::Context, id: Id, s: &SampleData, cols: usize) -> Arc<(ColKey, Vec<(f32, f32)>)> {
    let key: ColKey = (s.left.as_ptr() as usize, s.len(), cols);
    if let Some(c) = ctx.data_mut(|d| d.get_temp::<Arc<(ColKey, Vec<(f32, f32)>)>>(id)) {
        if c.0 == key {
            return c;
        }
    }
    let n = s.len().max(1);
    let v: Vec<(f32, f32)> = (0..cols)
        .map(|c| {
            let a = c * n / cols;
            let z = (((c + 1) * n) / cols).max(a + 1).min(n);
            let (mut lo, mut hi) = (0.0f32, 0.0f32);
            for i in a..z {
                let (l, r) = (s.left[i], s.right.get(i).copied().unwrap_or(s.left[i]));
                lo = lo.min(l).min(r);
                hi = hi.max(l).max(r);
            }
            (lo, hi)
        })
        .collect();
    let arc = Arc::new((key, v));
    ctx.data_mut(|d| d.insert_temp(id, arc.clone()));
    arc
}

/// Neon envelope: gradient fill that fades toward the centre line, a soft multi-layer glow around the
/// outline and a bright 1.4 px core. `strength` dims the whole thing (used for trimmed-away parts).
fn neon_wave(p: &Painter, rect: Rect, cols: &[(f32, f32)], color: Color32, strength: f32) {
    let n = cols.len();
    if n < 2 {
        return;
    }
    let mid = rect.center().y;
    let half = rect.height() * 0.5 * 0.94;
    let dx = rect.width() / n as f32;
    let min_t = 0.007;
    let mut top = Vec::with_capacity(n);
    let mut bot = Vec::with_capacity(n);
    for (i, &(lo, hi)) in cols.iter().enumerate() {
        let x = rect.left() + (i as f32 + 0.5) * dx;
        top.push(pos2(x, mid - hi.clamp(0.0, 1.0).max(min_t) * half));
        bot.push(pos2(x, mid + (-lo).clamp(0.0, 1.0).max(min_t) * half));
    }
    // gradient fill
    let a = |v: f32| (v * strength).clamp(0.0, 255.0) as u8;
    let mut mesh = Mesh::default();
    for i in 0..n {
        mesh.colored_vertex(top[i], alpha(color, a(105.0)));
        mesh.colored_vertex(pos2(top[i].x, mid), alpha(color, a(34.0)));
        mesh.colored_vertex(bot[i], alpha(color, a(105.0)));
    }
    for i in 0..n - 1 {
        let (c0, c1) = (3 * i as u32, 3 * (i as u32 + 1));
        mesh.add_triangle(c0, c0 + 1, c1);
        mesh.add_triangle(c0 + 1, c1 + 1, c1);
        mesh.add_triangle(c0 + 1, c0 + 2, c1 + 1);
        mesh.add_triangle(c0 + 2, c1 + 2, c1 + 1);
    }
    p.add(Shape::mesh(mesh));
    // glow + core
    let core = mix(color, Color32::WHITE, 0.32);
    for line in [&top, &bot] {
        for (w, al) in [(7.0_f32, 7.0_f32), (4.0, 15.0), (2.2, 34.0)] {
            p.add(Shape::line(line.clone(), Stroke::new(w, alpha(color, a(al)))));
        }
        p.add(Shape::line(line.clone(), Stroke::new(1.15_f32, alpha(core, a(255.0)))));
    }
}

pub(crate) struct WaveIn<'a> {
    pub sample: &'a SampleData,
    pub offset: u32,
    pub frames: u32,
    pub len: u32,
    pub sr: f32,
    pub fade_in_ms: f32,
    pub fade_out_ms: f32,
    pub reverse: bool,
    pub color: Color32,
    /// Playback position inside the sample (frames), if the clip is playing.
    pub play_at: Option<f32>,
}

#[derive(Default)]
pub(crate) struct WaveOut {
    pub trim_start: Option<u32>,
    pub trim_end: Option<u32>,
    pub fade_in_ms: Option<f32>,
    pub fade_out_ms: Option<f32>,
}

fn nice_step(total_secs: f32) -> f32 {
    let target = total_secs / 7.0;
    for s in [0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 30.0, 60.0, 120.0] {
        if s >= target {
            return s;
        }
    }
    300.0
}

/// The waveform panel with trim handles, fade handles, time ruler, hover read-out and playhead.
pub(crate) fn wave_panel(ui: &mut Ui, w: &WaveIn) -> WaveOut {
    let mut out = WaveOut::default();
    let ctx = ui.ctx().clone();
    let (outer, _) = ui.allocate_exact_size(vec2(ui.available_width(), 214.0), Sense::hover());
    let ruler_h = 20.0;
    let wr = Rect::from_min_max(outer.min + vec2(0.0, 0.0), pos2(outer.right(), outer.bottom() - ruler_h));
    let len_f = w.len.max(1) as f32;
    let total_s = len_f / w.sr.max(1.0);
    let x_of = |frame: f32| wr.left() + wr.width() * (frame / len_f);
    let frame_of = |x: f32| ((x - wr.left()) / wr.width().max(1.0)).clamp(0.0, 1.0) * len_f;
    let (fx0, fx1) = (x_of(w.offset as f32), x_of((w.offset + w.frames) as f32));
    let neon = neon_of(w.color);

    let p = ui.painter_at(outer.expand(8.0));
    // panel + grid
    p.rect_filled(outer, 12.0, WAVE_BG);
    let inner = wr.shrink2(vec2(0.0, 0.0));
    {
        let gp = p.with_clip_rect(outer);
        for k in 1..4 {
            let y = wr.top() + wr.height() * k as f32 / 4.0;
            gp.line_segment([pos2(wr.left(), y), pos2(wr.right(), y)], Stroke::new(1.0_f32, alpha(Color32::WHITE, if k == 2 { 26 } else { 9 })));
        }
        let step = nice_step(total_s);
        let mut t = 0.0;
        while t <= total_s + 1e-4 {
            let x = x_of(t * w.sr);
            gp.line_segment([pos2(x, wr.top()), pos2(x, wr.bottom())], Stroke::new(1.0_f32, alpha(Color32::WHITE, 8)));
            gp.line_segment([pos2(x, outer.bottom() - ruler_h), pos2(x, outer.bottom() - ruler_h + 5.0)], Stroke::new(1.0_f32, alpha(Color32::WHITE, 60)));
            let label = if step < 1.0 { format!("{:.2}s", t) } else { format!("{:.0}s", t) };
            if x + 30.0 < outer.right() {
                gp.text(pos2(x + 4.0, outer.bottom() - 7.0), Align2::LEFT_CENTER, label, FontId::proportional(10.0), MUTED);
            }
            t += step;
        }
    }
    // waveform: dim everywhere, neon inside the trimmed range
    let ppp = ctx.pixels_per_point();
    let cols_n = ((wr.width() * ppp).round() as usize).clamp(32, 4000);
    let cols = wave_columns(&ctx, Id::new("ed_wave_cols"), w.sample, cols_n);
    let area = Rect::from_min_max(wr.min + vec2(0.0, 6.0), wr.max - vec2(0.0, 6.0));
    neon_wave(&p.with_clip_rect(wr), area, &cols.1, Color32::from_rgb(120, 130, 150), 0.5);
    let live = Rect::from_min_max(pos2(fx0.max(wr.left()), wr.top()), pos2(fx1.min(wr.right()), wr.bottom()));
    neon_wave(&p.with_clip_rect(live), area, &cols.1, neon, 1.0);
    // veil over the trimmed-away parts
    p.rect_filled(Rect::from_min_max(wr.min, pos2(fx0, wr.bottom())), 0.0, Color32::from_black_alpha(120));
    p.rect_filled(Rect::from_min_max(pos2(fx1, wr.top()), wr.max), 0.0, Color32::from_black_alpha(120));

    // fades: shaded wedge above the ramp + ramp line + draggable dot
    let fi_x = x_of(w.offset as f32 + w.fade_in_ms * w.sr / 1000.0).clamp(fx0, fx1);
    let fo_x = x_of((w.offset + w.frames) as f32 - w.fade_out_ms * w.sr / 1000.0).clamp(fx0, fx1);
    let (ty, by) = (wr.top() + 14.0, wr.bottom() - 6.0);
    if fi_x - fx0 > 1.0 {
        p.add(Shape::convex_polygon(vec![pos2(fx0, by), pos2(fx0, ty), pos2(fi_x, ty)], Color32::from_black_alpha(110), Stroke::NONE));
        p.line_segment([pos2(fx0, by), pos2(fi_x, ty)], Stroke::new(3.0_f32, alpha(AMBER, 40)));
        p.line_segment([pos2(fx0, by), pos2(fi_x, ty)], Stroke::new(1.4_f32, AMBER));
    }
    if fx1 - fo_x > 1.0 {
        p.add(Shape::convex_polygon(vec![pos2(fx1, by), pos2(fx1, ty), pos2(fo_x, ty)], Color32::from_black_alpha(110), Stroke::NONE));
        p.line_segment([pos2(fo_x, ty), pos2(fx1, by)], Stroke::new(3.0_f32, alpha(AMBER, 40)));
        p.line_segment([pos2(fo_x, ty), pos2(fx1, by)], Stroke::new(1.4_f32, AMBER));
    }

    // hover read-out
    let hover = ui.input(|i| i.pointer.hover_pos()).filter(|h| wr.contains(*h));
    if let Some(h) = hover {
        let secs = frame_of(h.x) / w.sr.max(1.0);
        p.line_segment([pos2(h.x, wr.top()), pos2(h.x, wr.bottom())], Stroke::new(1.0_f32, alpha(Color32::WHITE, 34)));
        let g = ctx.fonts(|f| f.layout_no_wrap(format!("{secs:.3} s"), FontId::monospace(10.5), TEXT));
        let bx = (h.x + 8.0).min(wr.right() - g.size().x - 14.0);
        let r = Rect::from_min_size(pos2(bx, wr.top() + 6.0), g.size() + vec2(10.0, 4.0));
        p.rect_filled(r, 6.0, Color32::from_black_alpha(170));
        p.galley(r.min + vec2(5.0, 2.0), g, TEXT);
    }

    // trim handles: amber line + glow + grip pill
    for (k, x) in [fx0, fx1].into_iter().enumerate() {
        let hr = Rect::from_center_size(pos2(x, wr.center().y), vec2(18.0, wr.height()));
        let resp = ui.interact(hr, Id::new(("ed_trim", k)), Sense::drag());
        let act = ctx.animate_bool(resp.id, resp.hovered() || resp.dragged());
        if resp.hovered() || resp.dragged() {
            ctx.set_cursor_icon(egui::CursorIcon::ResizeHorizontal);
        }
        resp.clone().on_hover_text(if k == 0 { "Drag: start offset (trims the start)" } else { "Drag: end offset (trims the end)" });
        p.line_segment([pos2(x, wr.top()), pos2(x, wr.bottom())], Stroke::new(7.0_f32, alpha(AMBER, (16.0 + 30.0 * act) as u8)));
        p.line_segment([pos2(x, wr.top()), pos2(x, wr.bottom())], Stroke::new(1.6_f32, AMBER));
        let grip = Rect::from_center_size(pos2(x, wr.center().y), vec2(10.0 + 2.0 * act, 30.0 + 4.0 * act));
        p.rect_filled(grip.expand(3.0), 8.0, alpha(AMBER, (26.0 + 40.0 * act) as u8));
        p.rect_filled(grip, 6.0, AMBER);
        for dy in [-5.0_f32, 0.0, 5.0] {
            p.circle_filled(pos2(x, wr.center().y + dy), 1.1, Color32::from_rgb(70, 46, 0));
        }
        if resp.dragged() {
            if let Some(pt) = resp.interact_pointer_pos() {
                let frame = frame_of(pt.x) as u32;
                if k == 0 {
                    out.trim_start = Some(frame);
                } else {
                    out.trim_end = Some(w.len.saturating_sub(frame));
                }
            }
        }
    }

    // fade dots (drag to set the fade length)
    let max_ms = (w.frames as f32 / w.sr.max(1.0) * 1000.0).max(1.0);
    for (k, (x, y)) in [(fi_x, ty), (fo_x, ty)].into_iter().enumerate() {
        let hr = Rect::from_center_size(pos2(x, y), vec2(20.0, 20.0));
        let resp = ui.interact(hr, Id::new(("ed_fade", k)), Sense::drag());
        let act = ctx.animate_bool(resp.id, resp.hovered() || resp.dragged());
        if resp.hovered() || resp.dragged() {
            ctx.set_cursor_icon(egui::CursorIcon::ResizeHorizontal);
        }
        resp.clone().on_hover_text(if k == 0 { "Drag: fade in" } else { "Drag: fade out" });
        p.circle_filled(pos2(x, y), 9.0 + 2.0 * act, alpha(AMBER, (22.0 + 40.0 * act) as u8));
        p.circle_filled(pos2(x, y), 4.5, Color32::from_rgb(20, 22, 28));
        p.circle_stroke(pos2(x, y), 4.5, Stroke::new(1.6_f32, AMBER));
        if resp.dragged() {
            if let Some(pt) = resp.interact_pointer_pos() {
                let f = frame_of(pt.x);
                if k == 0 {
                    out.fade_in_ms = Some(((f - w.offset as f32) / w.sr * 1000.0).clamp(0.0, max_ms));
                } else {
                    out.fade_out_ms = Some((((w.offset + w.frames) as f32 - f) / w.sr * 1000.0).clamp(0.0, max_ms));
                }
            }
        }
    }

    // playhead
    if let Some(at) = w.play_at {
        let x = x_of(at);
        p.line_segment([pos2(x, wr.top()), pos2(x, wr.bottom())], Stroke::new(8.0_f32, alpha(Color32::WHITE, 16)));
        p.line_segment([pos2(x, wr.top()), pos2(x, wr.bottom())], Stroke::new(1.6_f32, Color32::WHITE));
        p.add(Shape::convex_polygon(vec![pos2(x - 5.0, wr.top()), pos2(x + 5.0, wr.top()), pos2(x, wr.top() + 7.0)], Color32::WHITE, Stroke::NONE));
    }
    if w.reverse {
        let r = Rect::from_min_size(pos2(wr.right() - 86.0, wr.top() + 8.0), vec2(76.0, 20.0));
        p.rect_filled(r, 10.0, alpha(NEON, 28));
        p.text(r.center(), Align2::CENTER_CENTER, "REVERSED", FontId::proportional(10.0), NEON);
    }
    let _ = (inner, Pos2::ZERO);
    out
}

/// A labelled settings row: muted label on the left, controls on the right.
pub(crate) fn row(ui: &mut Ui, label: &str, add: impl FnOnce(&mut Ui)) {
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 8.0;
        ui.add_sized([84.0, 24.0], egui::Label::new(RichText::new(label).size(12.5).color(MUTED)));
        add(ui);
    });
}

pub(crate) fn dot(ui: &mut Ui, color: Color32) {
    let (rect, _) = ui.allocate_exact_size(vec2(16.0, 16.0), Sense::hover());
    let p = ui.painter();
    p.circle_filled(rect.center(), 8.0, alpha(color, 38));
    p.circle_filled(rect.center(), 4.5, color);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample(v: Vec<f32>) -> SampleData {
        SampleData { name: "t".into(), sample_rate: 48_000.0, left: v.clone(), right: v }
    }

    #[test]
    fn wave_columns_hold_the_true_min_and_max_of_each_pixel_column() {
        let mut v = vec![0.0f32; 1000];
        v[130] = 0.8; // column 1 of 10
        v[420] = -0.6; // column 4
        let s = sample(v);
        let ctx = egui::Context::default();
        let c = wave_columns(&ctx, Id::new("t"), &s, 10);
        assert_eq!(c.1.len(), 10);
        assert!((c.1[1].1 - 0.8).abs() < 1e-6 && c.1[1].0 == 0.0);
        assert!((c.1[4].0 + 0.6).abs() < 1e-6);
        assert!(c.1.iter().enumerate().all(|(i, (lo, hi))| i == 1 || i == 4 || (*lo == 0.0 && *hi == 0.0)));
    }

    #[test]
    fn wave_columns_are_cached_and_recomputed_when_the_audio_or_width_changes() {
        let ctx = egui::Context::default();
        let a = sample(vec![0.1; 4800]);
        let c1 = wave_columns(&ctx, Id::new("t2"), &a, 100);
        let c2 = wave_columns(&ctx, Id::new("t2"), &a, 100);
        assert!(Arc::ptr_eq(&c1, &c2), "same input must come from the cache");
        let c3 = wave_columns(&ctx, Id::new("t2"), &a, 120);
        assert!(!Arc::ptr_eq(&c1, &c3) && c3.1.len() == 120, "a different width needs new columns");
        let b = sample(vec![0.5; 4800]);
        let c4 = wave_columns(&ctx, Id::new("t2"), &b, 120);
        assert!((c4.1[0].1 - 0.5).abs() < 1e-6, "new audio must not show the old envelope");
    }

    #[test]
    fn ruler_steps_stay_readable() {
        assert_eq!(nice_step(2.4), 0.5);
        assert_eq!(nice_step(0.05), 0.01);
        assert!(nice_step(600.0) >= 60.0);
        for secs in [0.1, 1.0, 3.7, 12.0, 90.0] {
            let n = secs / nice_step(secs);
            assert!((1.0..=12.0).contains(&n), "{secs}s gives {n} labels");
        }
    }

    #[test]
    fn neon_colours_keep_their_hue_and_reach_full_brightness() {
        let c = neon_of(Color32::from_rgb(40, 80, 120));
        assert_eq!(c.b(), 255);
        assert!(c.b() > c.g() && c.g() > c.r());
    }
}
